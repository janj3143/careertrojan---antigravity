"""
🎯 UMarketU Suite - Complete Career Marketing Platform
======================================================
Unified suite for discovering roles, analyzing fit, tailoring resumes, planning interviews,
and tracking applications with partner-aware life logistics.

Based on Product/Tech Spec [2025-10-25-01]
Consolidates pages: 12, 20, 21, 24, 25, 27
Backend services: Resume Upload (09), Career Intelligence (11)
"""

import json
import random
import re
import sys
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from statistics import mean, median
from typing import Any, Dict, List, Optional, Tuple
from uuid import uuid4

import pandas as pd
import plotly.graph_objects as go
import streamlit as st


BASE_DIR = Path(__file__).parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

ADMIN_PORTAL_DIR = BASE_DIR.parent / "admin_portal"
if str(ADMIN_PORTAL_DIR) not in sys.path:
    sys.path.insert(0, str(ADMIN_PORTAL_DIR))

try:
    from shared.config import USER_PORTAL_DATA_DIR, AI_DATA_DIR
except Exception:
    USER_PORTAL_DATA_DIR = BASE_DIR / "data"
    AI_DATA_DIR = BASE_DIR.parent / "ai_data_final"

try:
    from shared.state_bridge import (
        load_applications,
        save_applications,
        load_umarketu_snapshot,
        save_umarketu_snapshot,
        load_resume_snapshot,
        save_resume_snapshot,
    )
    STATE_BRIDGE_AVAILABLE = True
except Exception:
    STATE_BRIDGE_AVAILABLE = False

    def load_applications(*_args, **_kwargs):  # type: ignore
        return []

    def save_applications(*_args, **_kwargs):  # type: ignore
        return None

    def load_umarketu_snapshot(*_args, **_kwargs):  # type: ignore
        return {}

    def save_umarketu_snapshot(*_args, **_kwargs):  # type: ignore
        return None

    def load_resume_snapshot(*_args, **_kwargs):  # type: ignore
        return {}

    def save_resume_snapshot(*_args, **_kwargs):  # type: ignore
        return None

try:
    from shared.io_layer import get_io_layer
    IO_LAYER = get_io_layer()
except Exception:
    IO_LAYER = None

try:
    from services.user_data_service import UserDataService
    user_data_service = UserDataService()
    USER_DATA_SERVICE_AVAILABLE = True
except Exception:
    user_data_service = None
    USER_DATA_SERVICE_AVAILABLE = False

try:
    from token_management_system import init_token_system_for_page
    token_manager = init_token_system_for_page()
    TOKEN_MANAGER_AVAILABLE = True
except Exception:
    token_manager = None
    TOKEN_MANAGER_AVAILABLE = False

# Optional integrations with safety fallbacks
EMAIL_INTEGRATION_AVAILABLE = False
BLOCKER_ENGINE_AVAILABLE = False
WEB_INTELLIGENCE_AVAILABLE = False
JOB_TITLE_INTELLIGENCE_AVAILABLE = False
EMAIL_SERVICE_AVAILABLE = False
AI_API_AVAILABLE = False
RESUME_SERVICE_AVAILABLE = False

if IO_LAYER:
    WEB_INTELLIGENCE_AVAILABLE = True

job_title_bridge = None
email_service = None
email_bridge = None
ai_service = None
resume_parser_service = None


class EmailIntegrationBridge:
    def __init__(self) -> None:
        self.email_contacts = self._load_contact_index()

    def _load_contact_index(self) -> Dict[str, List[Dict[str, Any]]]:
        dataset_path = AI_DATA_DIR / "emails" / "emails_database.json"
        if not dataset_path.exists():
            return {}
        try:
            payload = json.loads(dataset_path.read_text(encoding="utf-8"))
        except Exception:
            return {}

        index: Dict[str, List[Dict[str, Any]]] = {}
        for entry in payload:
            email_value = entry.get("email")
            domain_value = (entry.get("domain") or "").lower()
            if not email_value or not domain_value:
                continue
            index.setdefault(domain_value, []).append(entry)
        return index

    def has_contacts(self) -> bool:
        return bool(self.email_contacts)

    def domain_count(self) -> int:
        return len(self.email_contacts)

    def _match_company_contacts(self, company_name: str) -> List[Dict[str, Any]]:
        if not company_name:
            return []
        normalized_company = re.sub(r"[^a-z0-9]", "", company_name.lower())
        matches: List[Dict[str, Any]] = []
        for domain, contacts in self.email_contacts.items():
            normalized_domain = re.sub(r"[^a-z0-9]", "", domain)
            if normalized_company and normalized_company in normalized_domain:
                matches.extend(contacts[:3])
            if len(matches) >= 5:
                break
        return matches[:5]

    def _extract_application_history(self, company_name: str) -> List[Dict[str, Any]]:
        applications = st.session_state.umarketu_state.get('applications', []) if 'umarketu_state' in st.session_state else []
        records: List[Dict[str, Any]] = []
        for entry in applications:
            target_company = entry.get('company') or entry.get('title')
            if not (company_name and target_company):
                continue
            if company_name.lower() in target_company.lower():
                records.append({
                    'date': entry.get('date_applied') or entry.get('last_update'),
                    'position': entry.get('job_title') or entry.get('title'),
                    'status': entry.get('status', 'Unknown')
                })
        return records[:5]

    def enhance_job_application_with_email_data(self, job: Dict[str, Any], user_email: Optional[str]) -> Dict[str, Any]:
        company_contacts = self._match_company_contacts(job.get('company', ''))
        history = self._extract_application_history(job.get('company', ''))
        networking_paths = []
        for contact in company_contacts:
            networking_paths.append({
                'path': f"Intro via {contact.get('email')}",
                'strength': 'Medium',
                'first_seen': contact.get('first_seen')
            })
        if user_email:
            networking_paths.append({
                'path': f"Leverage shared domain with {user_email.split('@')[-1]}",
                'strength': 'Contextual'
            })
        return {
            'company_contacts': company_contacts,
            'application_history': history,
            'networking_path': networking_paths[:5]
        }


def display_email_enhancement_options(context: str) -> None:
    if not (EMAIL_INTEGRATION_AVAILABLE and email_bridge and email_bridge.has_contacts()):
        st.caption("📧 Connect an email account in Admin Portal to unlock contact lookups")
        return
    st.caption(
        f"📧 Email intelligence online ({email_bridge.domain_count()} company domains indexed)"
    )


_COMPANY_LOOKUP_CACHE: Dict[str, Dict[str, Any]] = {}
_COMPANY_CACHE_LOADED = False


def _get_company_profile(company_name: str) -> Optional[Dict[str, Any]]:
    global _COMPANY_CACHE_LOADED
    if not company_name:
        return None
    key = company_name.lower()
    if key in _COMPANY_LOOKUP_CACHE:
        return _COMPANY_LOOKUP_CACHE[key]

    if not _COMPANY_CACHE_LOADED and IO_LAYER:
        try:
            records = IO_LAYER.get_companies(limit=1000)
            for record in records:
                label = record.get('name') or record.get('company_name')
                if not label:
                    continue
                _COMPANY_LOOKUP_CACHE[label.lower()] = record
            _COMPANY_CACHE_LOADED = True
        except Exception:
            _COMPANY_CACHE_LOADED = True

    if key in _COMPANY_LOOKUP_CACHE:
        return _COMPANY_LOOKUP_CACHE[key]

    for stored, payload in _COMPANY_LOOKUP_CACHE.items():
        if key in stored:
            return payload
    return None


def display_web_intelligence_enhancement(context: str, company_name: str, job_title: str) -> None:
    profile = _get_company_profile(company_name)
    if not profile:
        st.info("🌐 Company intelligence sync pending for this organization")
        return

    st.markdown(f"**{company_name}**")
    if profile.get('industry'):
        st.markdown(f"- Industry: {profile['industry']}")
    if profile.get('size'):
        st.markdown(f"- Size: {profile['size']}")
    if profile.get('location'):
        st.markdown(f"- HQ: {profile['location']}")
    sources = profile.get('top_sources') or profile.get('sources')
    if sources:
        preview = sources[:3] if isinstance(sources, list) else []
        if preview:
            st.caption("Recent sources:")
            for src in preview:
                st.caption(f"• {src}")


try:
    email_bridge = EmailIntegrationBridge()
    EMAIL_INTEGRATION_AVAILABLE = email_bridge.has_contacts()
except Exception:
    email_bridge = None
    EMAIL_INTEGRATION_AVAILABLE = False

try:
    from job_title_backend_integration import JobTitleBackend
    job_title_bridge = JobTitleBackend(user_id=st.session_state.get('user_id'))
    JOB_TITLE_INTELLIGENCE_AVAILABLE = True
except Exception:
    job_title_bridge = None


try:
    from admin_portal.templates.templates_engine import render_template_with_placeholders
    from admin_portal.templates.templates_registry import (
        TemplateCategory,
        get_template_by_slug,
        load_template_text,
        list_templates,
    )
    TEMPLATE_ENGINE_AVAILABLE = True
except Exception:
    TEMPLATE_ENGINE_AVAILABLE = False

try:
    from shared_backend.services.portal_bridge import ResumeService
    resume_parser_service = ResumeService()
    RESUME_SERVICE_AVAILABLE = True
except Exception:
    resume_parser_service = None

PREMIUM_TIERS = {"monthly_pro", "annual_pro", "enterprise_pro"}

USER_SILO_ROOT = Path("gdpr_compliant_data/user_data_silos")
if not USER_SILO_ROOT.exists():
    USER_SILO_ROOT = USER_PORTAL_DATA_DIR / "user_data_silos"
USER_SILO_ROOT.mkdir(parents=True, exist_ok=True)

_AI_INVENTORY_CACHE: Optional[Dict[str, Any]] = None


def ensure_umarketu_state() -> Dict[str, Any]:
    state = st.session_state.setdefault("umarketu_state", {})
    state.setdefault("applications", [])
    state.setdefault("fit_analysis", None)
    state.setdefault("peer_overlay", None)
    state.setdefault("selected_job", None)
    return state


def hydrate_umarketu_state(user_id: str) -> Dict[str, Any]:
    state = ensure_umarketu_state()
    if not (STATE_BRIDGE_AVAILABLE and user_id):
        return state
    if state.get("_hydrated_from_disk") == user_id:
        return state

    snapshot = load_umarketu_snapshot(user_id)
    if snapshot:
        state.update(snapshot)

    if not state.get("applications"):
        state["applications"] = load_applications(user_id)

    state["_hydrated_from_disk"] = user_id
    return state


def persist_umarketu_state(user_id: str) -> None:
    if not (STATE_BRIDGE_AVAILABLE and user_id):
        return
    snapshot = st.session_state.get("umarketu_state")
    if snapshot:
        try:
            save_umarketu_snapshot(user_id, snapshot)
        except Exception:
            pass


def ensure_applications_loaded(user_id: str) -> None:
    state = ensure_umarketu_state()
    if state.get("_applications_loaded"):
        return
    stored_apps: List[Dict[str, Any]] = []
    if STATE_BRIDGE_AVAILABLE and user_id:
        stored_apps = load_applications(user_id)
    elif state.get("applications"):
        stored_apps = state["applications"]
    if stored_apps:
        state["applications"] = stored_apps
    state["_applications_loaded"] = True


def get_ai_inventory_stats() -> Dict[str, Any]:
    global _AI_INVENTORY_CACHE
    if _AI_INVENTORY_CACHE:
        return _AI_INVENTORY_CACHE

    total_companies = 0
    dataset_name = "AI Data"
    if IO_LAYER:
        try:
            companies = IO_LAYER.get_companies()
            total_companies = len(companies)
        except Exception:
            total_companies = 0
    _AI_INVENTORY_CACHE = {
        "total_companies": total_companies,
        "dataset": dataset_name if total_companies else "Offline cache"
    }
    return _AI_INVENTORY_CACHE


def extract_resume_snapshot() -> Dict[str, Any]:
    snapshot = st.session_state.get("resume_data")
    if snapshot:
        return snapshot
    if STATE_BRIDGE_AVAILABLE:
        user_id = st.session_state.get('user_id')
        if user_id:
            stored_snapshot = load_resume_snapshot(user_id)
            if stored_snapshot:
                st.session_state['resume_data'] = stored_snapshot
                return stored_snapshot
    analysis = st.session_state.get("analysis_results")
    if analysis:
        return {
            "metadata": {
                "name": analysis.get("name"),
                "quality_score": analysis.get("basic_score"),
                "total_years_experience": analysis.get("experience_years", 0)
            },
            "skills": analysis.get("tech_keywords", [])
        }
    return {}


def extract_resume_skills(snapshot: Optional[Dict[str, Any]]) -> List[str]:
    if not snapshot:
        return []
    if isinstance(snapshot.get("skills"), list):
        return snapshot["skills"]
    metadata_skills = snapshot.get("metadata", {}).get("skills")
    if isinstance(metadata_skills, list):
        return metadata_skills
    return []


def get_resume_experience_years(snapshot: Dict[str, Any]) -> float:
    metadata_years = snapshot.get("metadata", {}).get("total_years_experience")
    if metadata_years:
        return metadata_years
    experience_entries = snapshot.get("experience") or snapshot.get("work_experience") or []
    if not experience_entries:
        return 0
    estimated_years = len(experience_entries) * 2
    return float(estimated_years)


def _extract_salary_bounds(value: Any) -> Dict[str, Optional[int]]:
    if isinstance(value, (int, float)):
        amount = int(value)
        return {"text": f"£{amount:,.0f}", "min": amount}
    if isinstance(value, str):
        digits = [int(match.replace(",", "")) for match in re.findall(r"\d[\d,]{3,}", value)]
        if not digits:
            try:
                amount = int(float(value))
                return {"text": f"£{amount:,.0f}", "min": amount}
            except ValueError:
                return {"text": value, "min": None}
        span = f"£{digits[0]:,}"
        if len(digits) > 1:
            span = f"£{digits[0]:,} - £{digits[-1]:,}"
        return {"text": span, "min": digits[0]}
    return {"text": "Competitive", "min": None}


def _compute_quick_fit(
    baseline_skills: List[str],
    required_skills: List[str],
    resume_years: float,
    min_experience: Optional[int],
    location_match_bonus: bool,
) -> int:
    base = {skill.lower() for skill in baseline_skills if skill}
    required = {skill.lower() for skill in required_skills if skill}
    if not base and required:
        base = set(required)
    overlap = (len(base & required) / len(required)) if required else 0.5
    experience_factor = 1.0
    if min_experience:
        experience_factor = min(resume_years / max(min_experience, 1), 1.0)
    location_bonus = 0.05 if location_match_bonus else 0
    score = (overlap * 70) + (experience_factor * 25) + (location_bonus * 100)
    return int(max(35, min(100, score)))


def _assemble_jd_payload(raw_job: Dict[str, Any]) -> Dict[str, Any]:
    jd_data = raw_job.get("jd_data", {}).copy()
    if not jd_data.get("required_skills"):
        jd_data["required_skills"] = (
            raw_job.get("required_skills")
            or raw_job.get("key_requirements")
            or raw_job.get("skills")
            or []
        )
    if not jd_data.get("responsibilities"):
        jd_data["responsibilities"] = (
            raw_job.get("responsibilities")
            or raw_job.get("responsibilities_summary")
            or raw_job.get("scope")
            or []
        )
    if not jd_data.get("min_experience_years"):
        jd_data["min_experience_years"] = (
            raw_job.get("min_experience")
            or raw_job.get("experience_years")
            or raw_job.get("experience_required")
            or 0
        )
    if not jd_data.get("required_education"):
        jd_data["required_education"] = raw_job.get("required_education") or raw_job.get("education") or ""
    return jd_data


def _normalise_job_payload(
    raw_job: Dict[str, Any],
    baseline_skills: List[str],
    resume_years: float,
    location_query: str,
) -> Optional[Dict[str, Any]]:
    title = raw_job.get("title") or raw_job.get("job_title") or raw_job.get("position")
    company = raw_job.get("company") or raw_job.get("employer") or raw_job.get("organisation")
    if not title or not company:
        return None

    location = raw_job.get("location") or raw_job.get("city") or raw_job.get("region") or "Remote"
    work_mode = raw_job.get("remote") or raw_job.get("work_mode") or "Hybrid"
    remote_label = (
        "Remote-friendly" if isinstance(work_mode, str) and "remote" in work_mode.lower()
        else work_mode if isinstance(work_mode, str)
        else "Hybrid"
    )

    salary_payload = _extract_salary_bounds(
        raw_job.get("salary")
        or raw_job.get("salary_range")
        or raw_job.get("compensation")
        or raw_job.get("band")
    )

    posted_on = (
        raw_job.get("posted")
        or raw_job.get("posted_at")
        or raw_job.get("_analysis_timestamp")
        or raw_job.get("timestamp")
        or datetime.now().strftime("%Y-%m-%d")
    )

    source = raw_job.get("source") or raw_job.get("_source") or "ai_data_final"

    jd_data = _assemble_jd_payload(raw_job)
    location_match = location_query and location_query.lower() in location.lower()
    quick_fit = _compute_quick_fit(
        baseline_skills,
        jd_data.get("required_skills", []),
        resume_years,
        jd_data.get("min_experience_years"),
        bool(location_match),
    )

    url = (
        raw_job.get("url")
        or raw_job.get("application_url")
        or f"https://www.google.com/search?q={company.replace(' ', '+')}+{title.replace(' ', '+')}"
    )

    return {
        "id": raw_job.get("id") or raw_job.get("job_id") or f"job_{uuid4().hex[:8]}",
        "title": title,
        "company": company,
        "location": location,
        "remote": remote_label,
        "salary": salary_payload["text"],
        "salary_min": salary_payload["min"],
        "posted": posted_on,
        "source": source,
        "quick_fit": quick_fit,
        "url": url,
        "jd_data": jd_data,
    }


def _job_matches_filters(
    job: Dict[str, Any],
    job_titles: List[str],
    location_query: str,
    remote_ok: bool,
    salary_floor: int,
) -> bool:
    if job_titles:
        title_text = job["title"].lower()
        if not any(target.lower() in title_text for target in job_titles if target):
            return False

    if location_query:
        in_location = location_query.lower() in job["location"].lower()
        if not in_location and not (remote_ok and "remote" in job["remote"].lower()):
            return False

    if not remote_ok and "remote" in job["remote"].lower():
        return False

    if salary_floor and job.get("salary_min") and job["salary_min"] < salary_floor:
        return False

    return True


def _load_candidate_job_opportunities(limit: int = 40) -> List[Dict[str, Any]]:
    if not IO_LAYER:
        return []
    opportunities: List[Dict[str, Any]] = []
    try:
        candidate_ids = IO_LAYER.list_candidate_analyses(limit=limit)
    except Exception:
        candidate_ids = []

    for candidate_id in candidate_ids:
        try:
            analysis = IO_LAYER.get_candidate_analysis(candidate_id)
        except Exception:
            continue
        if not analysis:
            continue
        job_payload = analysis.get("job_opportunity")
        if job_payload:
            metadata = analysis.get("metadata", {})
            job_payload = job_payload.copy()
            job_payload["_source"] = "candidate_analysis"
            if metadata.get("analysis_timestamp"):
                job_payload["_analysis_timestamp"] = metadata["analysis_timestamp"]
            opportunities.append(job_payload)
    return opportunities


def build_search_results(
    search_skills: List[str],
    job_titles: List[str],
    location: str,
    salary_floor: int,
    remote_preference: bool,
) -> List[Dict[str, Any]]:
    resume_snapshot = extract_resume_snapshot()
    resume_skills = extract_resume_skills(resume_snapshot)
    resume_years = get_resume_experience_years(resume_snapshot) if resume_snapshot else 0
    baseline_skills = search_skills or resume_skills

    raw_jobs: List[Dict[str, Any]] = []
    if IO_LAYER:
        try:
            job_filters = {"location": location} if location else None
            raw_jobs = IO_LAYER.get_jobs(filters=job_filters, limit=80)
        except Exception:
            raw_jobs = []

    if not raw_jobs:
        raw_jobs = _load_candidate_job_opportunities(limit=60)

    normalised: List[Dict[str, Any]] = []
    for raw_job in raw_jobs:
        normalised_job = _normalise_job_payload(raw_job, baseline_skills, resume_years, location)
        if not normalised_job:
            continue
        if not _job_matches_filters(normalised_job, job_titles, location, remote_preference, salary_floor):
            continue
        normalised.append(normalised_job)

    return normalised[:30]


def build_peer_overlay(selected_job: Optional[Dict[str, Any]], fit_score: Optional[int], user_id: str) -> Optional[Dict[str, Any]]:
    if not (selected_job and fit_score is not None and USER_DATA_SERVICE_AVAILABLE and user_data_service):
        return None

    try:
        peers = user_data_service.get_peer_candidates(user_id=user_id, limit=50)
    except Exception:
        return None

    jd_data = selected_job.get("jd_data", {}) if selected_job else {}
    required_skills = [skill.lower() for skill in jd_data.get("required_skills", []) if skill]
    min_experience = jd_data.get("min_experience_years", 0)

    peer_scores: List[int] = []
    sample_rows: List[Dict[str, Any]] = []
    for peer in peers:
        profile = peer.get("profile", {})
        peer_skills = [skill.lower() for skill in profile.get("skills", [])]
        overlap = 0.0
        if required_skills:
            overlap = sum(1 for skill in required_skills if skill in peer_skills) / len(required_skills)
        peer_years = profile.get("experience_years")
        if peer_years is None:
            peer_years = len(profile.get("experience", [])) * 2
        exp_ratio = min(peer_years / max(min_experience, 1), 1) if min_experience else 1
        score = int((overlap * 70) + (exp_ratio * 30))
        peer_scores.append(score)
        sample_rows.append({
            "name": profile.get("name", "Peer"),
            "score": score,
            "skills": ", ".join(profile.get("skills", [])[:5])
        })

    if not peer_scores:
        return None

    cohort_size = len(peer_scores)
    sorted_scores = sorted(peer_scores)
    percentile_rank = int((sum(1 for value in sorted_scores if value <= fit_score) / cohort_size) * 100)
    avg_fit = int(mean(peer_scores))
    top_index = max(int(cohort_size * 0.9) - 1, 0)
    top_threshold = sorted_scores[top_index]

    if percentile_rank >= 90:
        rank_label = "Top 10%"
    elif percentile_rank >= 75:
        rank_label = "Top Quartile"
    elif percentile_rank >= 50:
        rank_label = "Above Median"
    else:
        rank_label = "Emerging"

    return {
        "percentile": percentile_rank,
        "rank": rank_label,
        "cohort_size": cohort_size,
        "avg_fit": avg_fit,
        "top_10_fit": top_threshold,
        "distribution": sorted_scores,
        "sample": sample_rows[:5]
    }


def generate_tuned_resume(
    resume_snapshot: Dict[str, Any],
    selected_job: Dict[str, Any],
    fit_analysis: Dict[str, Any],
    options: Dict[str, Any],
) -> Dict[str, Any]:
    job_title = selected_job.get("title", "Target Role")
    company = selected_job.get("company", "Target Company")
    resume_name = (
        resume_snapshot.get("metadata", {}).get("name")
        or st.session_state.get("profile_data", {}).get("first_name")
        or "Professional"
    )
    skills = extract_resume_skills(resume_snapshot)
    strengths = [tp.get("skill") for tp in fit_analysis.get("touch_points", [])][:3]
    if not strengths and skills:
        strengths = skills[:3]
    gaps = [bp.get("requirement") for bp in fit_analysis.get("block_points", [])][:3]

    experience_entries = resume_snapshot.get("experience") or resume_snapshot.get("work_experience") or []
    tailored_bullets: List[str] = []
    for entry in experience_entries[:3]:
        role = entry.get("title") or entry.get("role") or "Key Experience"
        company_name = entry.get("company", "Previous Company")
        desc = entry.get("description") or entry.get("summary") or "Delivered measurable results."
        tailored_bullets.append(f"{role} @ {company_name}: {desc.strip()}")

    headline_style = options.get("headline_style", "Achievement-focused")
    if headline_style == "Skill-focused" and strengths:
        headline = f"{resume_name} | {job_title} | {' • '.join(strengths)}"
    elif headline_style == "Impact-focused" and tailored_bullets:
        headline = f"{resume_name} | {job_title} candidate who {tailored_bullets[0].split(':')[1].strip()[:90]}"
    elif headline_style == "Hybrid" and strengths:
        headline = f"{resume_name} | {strengths[0]} • {strengths[1] if len(strengths) > 1 else job_title}"[:120]
    else:
        headline = f"{resume_name} | {job_title} alignment"

    summary = (
        f"Aligning {options.get('bullet_format', 'STAR')} storytelling to {company}'s {job_title} brief by surfacing "
        f"strengths in {', '.join(strengths) if strengths else 'core capabilities'} "
        f"and explicitly addressing {', '.join(gaps) if gaps else 'remaining gaps'} via {', '.join(options.get('gap_strategy', []))}."
    )

    quality_score = resume_snapshot.get("metadata", {}).get("quality_score") or fit_analysis.get("fit_score", 70)
    ats_projection = min(100, int(quality_score + len(gaps) * 2))

    return {
        "version_id": f"tailored_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        "headline": headline,
        "summary": summary,
        "changes": len(tailored_bullets) + len(gaps),
        "created_at": datetime.now().isoformat(),
        "bullets": tailored_bullets,
        "skills_to_emphasize": strengths,
        "gaps_to_close": gaps,
        "ats_projection": ats_projection,
        "original_headline": resume_snapshot.get("headline") or resume_snapshot.get("summary", "Master Resume"),
        "original_summary": resume_snapshot.get("summary") or resume_snapshot.get("profile", {}).get("summary", ""),
    }


def append_timeline_event(application: Dict[str, Any], date_value: datetime, event: str, details: str) -> None:
    timeline = application.setdefault("timeline", [])
    timeline.append({
        "date": date_value.strftime("%Y-%m-%d"),
        "event": event,
        "details": details,
    })


def format_status_badge(status: str) -> str:
    normalized = status.lower()
    if "offer" in normalized:
        return "🟢 Offer"
    if "interview" in normalized:
        return "🟡 Interview"
    if "screen" in normalized:
        return "🔵 Phone Screen"
    if "rejected" in normalized:
        return "🔴 Rejected"
    return f"🔘 {status.title()}"


def build_candidate_identity(profile_snapshot: Dict[str, Any], resume_snapshot: Dict[str, Any]) -> Dict[str, Any]:
    metadata = resume_snapshot.get('metadata', {}) if isinstance(resume_snapshot, dict) else {}
    first_name = profile_snapshot.get('first_name') or metadata.get('first_name')
    last_name = profile_snapshot.get('last_name') or metadata.get('last_name')
    composed_name = " ".join(filter(None, [first_name, last_name])).strip()
    candidate_name = composed_name or metadata.get('name') or profile_snapshot.get('full_name')
    if not candidate_name:
        candidate_name = profile_snapshot.get('email') or st.session_state.get('user_email') or "Candidate"

    return {
        'candidate_name': candidate_name,
        'candidate_email': profile_snapshot.get('email') or metadata.get('email') or st.session_state.get('user_email', ''),
        'candidate_phone': profile_snapshot.get('phone') or metadata.get('phone') or profile_snapshot.get('contact_number', ''),
        'years_experience': metadata.get('total_years_experience') or get_resume_experience_years(resume_snapshot) or profile_snapshot.get('experience_years'),
        'current_role_summary': profile_snapshot.get('current_role') or metadata.get('current_role'),
        'headline': profile_snapshot.get('headline') or resume_snapshot.get('summary'),
        'top_skills': ", ".join(extract_resume_skills(resume_snapshot)[:5]),
    }


def build_followup_placeholders(
    company_name: str,
    role_title: str,
    profile_snapshot: Dict[str, Any],
    resume_snapshot: Dict[str, Any],
    context_overrides: Dict[str, Any],
) -> Dict[str, Any]:
    identity = build_candidate_identity(profile_snapshot, resume_snapshot)
    placeholders: Dict[str, Any] = {
        'candidate_name': identity['candidate_name'],
        'candidate_email': identity['candidate_email'],
        'candidate_phone': identity['candidate_phone'],
        'role_title': role_title or st.session_state.umarketu_state.get('selected_job', {}).get('title', 'Target Role'),
        'company_name': company_name or st.session_state.umarketu_state.get('selected_job', {}).get('company', 'Target Company'),
        'interview_date': datetime.now().strftime('%d %B %Y'),
        'interview_time': context_overrides.get('interview_time', '09:00'),
        'team_or_project': context_overrides.get('team_or_project') or st.session_state.umarketu_state.get('selected_job', {}).get('department', 'the team'),
        'challenge_or_goal': context_overrides.get('challenge_or_goal') or 'the upcoming roadmap goals',
        'specific_element_you_liked': context_overrides.get('specific_element_you_liked') or 'the product direction discussed',
        'relevant_experience': context_overrides.get('relevant_experience') or identity.get('headline') or identity.get('current_role_summary', ''),
        'hiring_manager_name': context_overrides.get('hiring_manager_name') or context_overrides.get('interviewer_name', 'Hiring Manager'),
    }
    placeholders.update(context_overrides)
    placeholders.setdefault('interviewer_name', context_overrides.get('interviewer_name', 'Hiring Manager'))
    return placeholders


def build_interview_question_sections(
    company_name: str,
    selected_job: Optional[Dict[str, Any]],
    resume_snapshot: Dict[str, Any],
    fit_analysis: Optional[Dict[str, Any]],
) -> Dict[str, List[str]]:
    sections: Dict[str, List[str]] = {}
    jd_data = (selected_job or {}).get('jd_data', {}) if selected_job else {}

    if fit_analysis:
        touch_points = fit_analysis.get('touch_points') or []
        if touch_points:
            sections['Strength Alignment'] = [
                f"Can you share a recent story where you demonstrated {tp.get('skill', 'this requirement')} and delivered measurable impact?"
                for tp in touch_points[:5]
            ]

        block_points = fit_analysis.get('block_points') or []
        if block_points:
            sections['Gap Mitigation'] = [
                f"What is your plan to close the gap on {bp.get('requirement')} for {company_name}?"
                for bp in block_points[:5]
            ]

    responsibilities = jd_data.get('responsibilities') or []
    if responsibilities:
        sections['Company-Specific Focus'] = [
            f"How would you approach {resp.lower()} for {company_name}?"
            for resp in responsibilities[:5]
        ]

    experience_entries = resume_snapshot.get('experience') or resume_snapshot.get('work_experience') or []
    if experience_entries:
        sections['Career Story'] = [
            f"Walk me through your time at {entry.get('company', 'your previous employer')} where you {entry.get('description', 'drove outcomes')}"
            for entry in experience_entries[:5]
        ]

    if not sections:
        sections['Profile Required'] = [
            "Upload your resume and run Fit Analysis to unlock personalised interview questions."
        ]

    return sections


def derive_target_roles_from_snapshot(snapshot: Dict[str, Any]) -> str:
    if not snapshot:
        return ""
    metadata = snapshot.get('metadata', {})
    candidate_fields: List[Any] = [
        snapshot.get('target_roles'),
        snapshot.get('desired_roles'),
        snapshot.get('preferred_roles'),
        metadata.get('target_roles'),
        metadata.get('preferred_roles'),
        snapshot.get('headline') or snapshot.get('summary'),
        metadata.get('headline'),
    ]
    for field in candidate_fields:
        if isinstance(field, list):
            cleaned = [str(item).strip() for item in field if item]
            if cleaned:
                return ", ".join(cleaned[:3])
        elif isinstance(field, str) and field.strip():
            return field.strip()
    return ""


def parse_partner_resume_upload(uploaded_file: Any) -> Optional[Dict[str, Any]]:
    if not uploaded_file:
        return None
    file_bytes = uploaded_file.getvalue() if hasattr(uploaded_file, 'getvalue') else uploaded_file.read()
    suffix = Path(uploaded_file.name).suffix or ".bin"
    temp_path: Optional[Path] = None
    parsed: Optional[Dict[str, Any]] = None

    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(file_bytes)
            temp_path = Path(tmp.name)

        if RESUME_SERVICE_AVAILABLE and resume_parser_service:
            resume_id = f"partner_{st.session_state.get('user_id', 'user')}_{int(datetime.now().timestamp())}"
            parsed = resume_parser_service.parse(
                file_path=str(temp_path),
                user_id=st.session_state.get('user_id'),
                resume_id=resume_id,
            )
            if parsed and parsed.get('error'):
                st.error(f"Resume parsing error: {parsed['error']}")
                parsed = None

        if not parsed:
            if uploaded_file.type == "text/plain":
                parsed = {
                    'raw_text': file_bytes.decode('utf-8', errors='ignore'),
                    'metadata': {'file_name': uploaded_file.name},
                }
            else:
                st.error("Resume parsing service is offline. Please upload a .txt resume or re-try later.")
                return None

        parsed.setdefault('metadata', {})
        parsed['metadata'].setdefault('file_name', uploaded_file.name)
        parsed['metadata'].setdefault('uploaded_at', datetime.now().isoformat())
        return parsed
    finally:
        if temp_path and temp_path.exists():
            temp_path.unlink(missing_ok=True)


def _split_role_keywords(raw_roles: str) -> List[str]:
    if not raw_roles:
        return []
    tokens = re.split(r"[;,/]|\band\b", raw_roles, flags=re.IGNORECASE)
    return [token.strip().lower() for token in tokens if token.strip()]


def _derive_city_label(location_value: Optional[str]) -> str:
    if not location_value:
        return "Remote / Hybrid"
    label = str(location_value).strip()
    if not label:
        return "Remote / Hybrid"
    if "remote" in label.lower():
        return label
    parts = [part.strip() for part in re.split(r"[,|/|-]", label) if part.strip()]
    if len(parts) >= 2:
        return f"{parts[0]}, {parts[1]}"
    return parts[0] if parts else label


def _load_partner_job_pool(limit: int = 600) -> Tuple[List[Dict[str, Any]], str]:
    job_pool: List[Dict[str, Any]] = []
    source = "io_layer"
    if IO_LAYER:
        try:
            job_pool = IO_LAYER.get_jobs(limit=limit)
        except Exception:
            job_pool = []
    if not job_pool:
        state = st.session_state.get('umarketu_state', {})
        job_pool = state.get('search_results', []) or []
        source = "session_search"
    return job_pool, source


def _job_matches_partner_profile(job: Dict[str, Any], profile: Dict[str, Any]) -> bool:
    title = (job.get('title') or '').lower()
    role_keywords = profile.get('role_keywords') or []
    if role_keywords and not any(keyword in title for keyword in role_keywords):
        return False

    salary_floor = profile.get('min_salary')
    salary_min = job.get('salary_min')
    if salary_floor and salary_min and salary_min < salary_floor:
        return False

    remote_pref = profile.get('remote_flex')
    remote_label = (job.get('remote') or job.get('location') or '').lower()
    if remote_pref == "On-site only" and "remote" in remote_label:
        return False
    if remote_pref == "Fully Remote" and "remote" not in remote_label:
        return False

    return True


def _filter_partner_jobs(job_pool: List[Dict[str, Any]], profile: Dict[str, Any]) -> List[Dict[str, Any]]:
    baseline_skills = profile.get('skills') or [kw.title() for kw in profile.get('role_keywords', [])]
    matches: List[Dict[str, Any]] = []
    for raw_job in job_pool:
        normalized = _normalise_job_payload(
            raw_job,
            baseline_skills=baseline_skills,
            resume_years=profile.get('experience_years', 0.0),
            location_query=profile.get('home_base', ''),
        )
        if not normalized:
            continue
        if normalized.get('quick_fit', 0) < profile.get('min_fit_score', 45):
            continue
        if not _job_matches_partner_profile(normalized, profile):
            continue
        location_value = normalized.get('location')
        normalized['city_label'] = _derive_city_label(location_value)
        remote_label = (normalized.get('remote') or '')
        normalized['is_remote'] = (
            "remote" in remote_label.lower()
            or "remote" in (location_value or '').lower()
        )
        matches.append(normalized)
    return matches


def _aggregate_city_matches(
    p1_jobs: List[Dict[str, Any]],
    p2_jobs: List[Dict[str, Any]],
    relocation_allowed: bool,
    relocation_budget: int,
    home_base: str,
    avg_commute_limit: float,
) -> List[Dict[str, Any]]:
    city_map: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
    for job in p1_jobs:
        payload = city_map.setdefault(job['city_label'], {'p1': [], 'p2': []})
        payload['p1'].append(job)
    for job in p2_jobs:
        payload = city_map.setdefault(job['city_label'], {'p1': [], 'p2': []})
        payload['p2'].append(job)

    if not city_map:
        return []

    if not relocation_allowed and home_base:
        filtered = {
            city: payload for city, payload in city_map.items() if home_base.lower() in city.lower()
        }
        if filtered:
            city_map = filtered

    avg_commute_limit = max(avg_commute_limit, 10)
    max_density = max((len(payload['p1']) + len(payload['p2']) for payload in city_map.values()), default=0)

    city_rows: List[Dict[str, Any]] = []
    for city, payload in city_map.items():
        if not payload['p1'] or not payload['p2']:
            continue
        total_jobs = len(payload['p1']) + len(payload['p2'])
        remote_share = (
            sum(1 for job in payload['p1'] + payload['p2'] if job.get('is_remote')) / total_jobs
        ) if total_jobs else 0.0
        salary_samples = [job.get('salary_min') for job in payload['p1'] + payload['p2'] if job.get('salary_min')]
        salary_low = min(salary_samples) if salary_samples else None
        salary_high = max(salary_samples) if salary_samples else None
        median_salary = int(median(salary_samples)) if salary_samples else None
        capacity_factor = min(1.0, avg_commute_limit / 60)
        commute_fit = min(1.0, (remote_share * 0.6) + (capacity_factor * 0.4))
        estimated_commute_minutes = int(max(12, (avg_commute_limit * 1.2) * (1 - (remote_share * 0.4))))
        density_score = (total_jobs / max_density) if max_density else 0
        balance_score = (
            min(len(payload['p1']), len(payload['p2'])) / max(len(payload['p1']), len(payload['p2']))
        ) if max(len(payload['p1']), len(payload['p2'])) else 0
        relocation_bonus = 0.05 if relocation_allowed else 0.0
        combined_score = int(
            min(1.0, (density_score * 0.4) + (balance_score * 0.2) + (remote_share * 0.2) + (commute_fit * 0.2) + relocation_bonus)
            * 100
        )
        if not relocation_budget:
            budget_alignment = "Flexible"
        elif median_salary is None:
            budget_alignment = "Unknown"
        elif median_salary >= relocation_budget * 2:
            budget_alignment = "Covered"
        elif median_salary >= relocation_budget:
            budget_alignment = "Tight"
        else:
            budget_alignment = "Needs Review"

        city_rows.append({
            'city': city,
            'p1_job_count': len(payload['p1']),
            'p2_job_count': len(payload['p2']),
            'combined_score': combined_score,
            'remote_share': remote_share,
            'median_salary': median_salary,
            'salary_low': salary_low,
            'salary_high': salary_high,
            'budget_alignment': budget_alignment,
            'commute_fit': commute_fit,
            'estimated_commute_minutes': estimated_commute_minutes,
            'p1_jobs': sorted(payload['p1'], key=lambda job: job.get('quick_fit', 0), reverse=True),
            'p2_jobs': sorted(payload['p2'], key=lambda job: job.get('quick_fit', 0), reverse=True),
        })

    return sorted(city_rows, key=lambda row: row['combined_score'], reverse=True)


def build_dual_career_recommendations(
    p1_profile: Dict[str, Any],
    p2_profile: Dict[str, Any],
    relocation_allowed: bool,
    relocation_budget: int,
) -> Dict[str, Any]:
    job_pool, job_source = _load_partner_job_pool()
    if not job_pool:
        return {'cities': [], 'job_source': job_source, 'p1_total_jobs': 0, 'p2_total_jobs': 0}

    p1_jobs = _filter_partner_jobs(job_pool, p1_profile)
    p2_jobs = _filter_partner_jobs(job_pool, p2_profile)
    avg_commute_limit = (
        (p1_profile.get('max_commute', 0) + p2_profile.get('max_commute', 0)) / 2
    )

    city_rows = _aggregate_city_matches(
        p1_jobs,
        p2_jobs,
        relocation_allowed=relocation_allowed,
        relocation_budget=relocation_budget,
        home_base=p1_profile.get('home_base', ''),
        avg_commute_limit=avg_commute_limit,
    )

    return {
        'cities': city_rows,
        'job_source': job_source,
        'p1_total_jobs': len(p1_jobs),
        'p2_total_jobs': len(p2_jobs),
    }

# Token + profile status sourced from live systems
user_id = st.session_state.get('user_id', 'demo_user')
umarketu_state = hydrate_umarketu_state(user_id)
ensure_applications_loaded(user_id)
user_tier = st.session_state.get('subscription_plan', 'free')
page_name_aliases = [Path(__file__).name, "10_UMarketU_Suite.py"]
token_cost = 0
token_balance = None
if TOKEN_MANAGER_AVAILABLE and token_manager and user_id:
    for alias in page_name_aliases:
        cost = token_manager.get_page_token_cost(alias)
        if cost:
            token_cost = cost
            break
    token_balance = token_manager.get_user_token_balance(user_id)
    st.info(
        f"💎 **Live Token Cost:** {token_cost} | **Balance:** {token_balance} tokens — "
        "data synced with Admin Token Management"
    )
else:
    st.info("💎 Token data unavailable (Token Manager not initialised)")

profile_data = st.session_state.get('profile_data', {})
profile_fields = ['first_name', 'last_name', 'email', 'current_role', 'skills', 'career_goals']
filled_fields = [profile_data.get(field) for field in profile_fields if profile_data.get(field)]
profile_completion = int((len(filled_fields) / len(profile_fields)) * 100) if profile_fields else 0
ai_inventory = get_ai_inventory_stats()

profile_col1, profile_col2, profile_col3 = st.columns([2, 1, 1])
with profile_col1:
    st.metric("👤 Profile Completion", f"{profile_completion}%", help="Update via Complete Profile page")
with profile_col2:
    if st.button("Open Profile Manager", use_container_width=True):
        st.switch_page("pages/07_Profile_Complete.py")
with profile_col3:
    st.metric(
        "📚 AI Dataset",
        f"{ai_inventory['total_companies']:,}",
        help=f"Source: {ai_inventory['dataset']}"
    )

resume_snapshot = extract_resume_snapshot()
resume_skills = extract_resume_skills(resume_snapshot)
fit_analysis = st.session_state.umarketu_state.get('fit_analysis')
applications = st.session_state.umarketu_state.get('applications', [])
analysis_results = st.session_state.get('analysis_results', {})
enriched_data = st.session_state.get('enriched_data', {})

match_rate_value = None
if fit_analysis:
    match_rate_value = fit_analysis.get('fit_score')
elif analysis_results.get('basic_score'):
    match_rate_value = analysis_results['basic_score']

interview_count = sum(1 for app in applications if 'interview' in app.get('status', '').lower())
offer_count = sum(1 for app in applications if 'offer' in app.get('status', '').lower())
total_apps = len(applications)
interview_rate = int((interview_count / total_apps) * 100) if total_apps else None
offer_rate = int((offer_count / total_apps) * 100) if total_apps else None

time_samples = [app.get('time_to_apply_minutes') for app in applications if app.get('time_to_apply_minutes')]
avg_time_to_apply = int(sum(time_samples) / len(time_samples)) if time_samples else None

quality_score = (
    enriched_data.get('ats_score')
    or resume_snapshot.get('metadata', {}).get('quality_score')
    or analysis_results.get('basic_score')
)

col1, col2, col3, col4, col5 = st.columns(5)
with col1:
    st.metric(
        "🎯 Match Rate",
        f"{match_rate_value:.0f}%" if match_rate_value is not None else "—",
        help="Fit score generated from your actual resume analysis"
    )
with col2:
    st.metric(
        "📧 Interview Rate",
        f"{interview_rate}%" if interview_rate is not None else "—",
        help="Calculated from your tracked applications"
    )
with col3:
    st.metric(
        "🏆 Offer Rate",
        f"{offer_rate}%" if offer_rate is not None else "—",
        help="Offer conversions from logged applications"
    )
with col4:
    st.metric(
        "⏱️ Time to Apply",
        f"{avg_time_to_apply} min" if avg_time_to_apply is not None else "—",
        help="Measured from last search to recorded application"
    )
with col5:
    score_display = f"{quality_score}/100" if isinstance(quality_score, (int, float)) else "—"
    st.metric(
        "⭐ Quality Score",
        score_display,
        help="ATS score surfaced from resume parsing"
    )

st.markdown("---")

# Navigation tabs for suite sections
tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "🔍 Job Discovery",
    "📊 Fit Analysis",
    "📝 Resume Tuning",
    "📋 Application Tracker",
    "🎤 Interview Coach",
    "👥 Partner Mode"
])

# ===========================
# TAB 1: JOB DISCOVERY
# ===========================
with tab1:
    st.header("🔍 Job Discovery & Search")
    st.markdown("**US1**: Search across Google/LinkedIn/company career pages with your skills & location radius")

    # Search filters
    col1, col2 = st.columns([2, 1])

    # Load user's REAL skills from their CV analysis
    user_id = st.session_state.get('user_id', 'demo_user')
    user_silo = Path(f"gdpr_compliant_data/user_data_silos/{user_id}")

    user_skills = []
    user_job_titles = ""

    if user_silo.exists():
        cv_analysis_file = user_silo / "cv_analysis.json"
        if cv_analysis_file.exists():
            try:
                with open(cv_analysis_file, 'r', encoding='utf-8') as f:
                    cv_data = json.load(f)
                    user_skills = cv_data.get('extracted_skills', [])
                    user_job_titles = cv_data.get('target_roles', '')
            except:
                pass

    # If no CV data, show message
    if not user_skills:
        st.info("📄 Upload your resume first to get personalized job matches based on your actual skills!")
        user_skills = []  # Empty list, not fake data

    with col1:
        search_skills = st.multiselect(
            "🎯 Your Core Skills",
            user_skills if user_skills else ["Add your skills by uploading your resume"],
            default=user_skills[:3] if len(user_skills) >= 3 else user_skills,
            help="These are loaded from your uploaded resume"
        )

        job_titles = st.text_input(
            "💼 Target Job Titles",
            value=user_job_titles if user_job_titles else "",
            help="From your resume or enter manually"
        )

    with col2:
        default_location = (
            profile_data.get('location')
            or resume_snapshot.get('metadata', {}).get('location')
            or st.session_state.get('analysis_results', {}).get('location')
            or ""
        )
        location = st.text_input("📍 Location", value=default_location, help="Loaded from your uploaded resume when available")
        radius_km = st.slider("📏 Search Radius (km)", 0, 100, 25, 5)

        remote_ok = st.checkbox("🏠 Include Remote Jobs", value=True)

        salary_min = st.number_input("💰 Min Salary (£)", 0, 200000, 50000, 5000)

    # Advanced filters (collapsible)
    with st.expander("🔧 Advanced Filters"):
        col1, col2 = st.columns(2)
        with col1:
            experience_level = st.select_slider(
                "📊 Experience Level",
                options=["Entry", "Mid", "Senior", "Lead", "Executive"],
                value="Mid"
            )
            company_size = st.multiselect(
                "🏢 Company Size",
                ["Startup (<50)", "Small (50-200)", "Medium (200-1000)", "Large (1000+)"],
                default=["Medium (200-1000)", "Large (1000+)"]
            )
        with col2:
            job_type = st.multiselect(
                "📄 Job Type",
                ["Full-time", "Part-time", "Contract", "Freelance"],
                default=["Full-time"]
            )
            posted_within = st.selectbox(
                "📅 Posted Within",
                ["24 hours", "7 days", "30 days", "Any time"],
                index=1
            )

    # Search button
    if st.button("🔍 Search Jobs", type="primary", use_container_width=True):
        if not search_skills and not resume_skills:
            st.error("⚠️ Upload your resume or manually select skills to personalise search results.")
            st.stop()

        with st.spinner("🔄 Connecting to ai_data companies dataset..."):
            requested_titles = [title.strip() for title in job_titles.split(',') if title.strip()]
            search_results = build_search_results(
                search_skills=search_skills,
                job_titles=requested_titles,
                location=location,
                salary_floor=int(salary_min or 0),
                remote_preference=remote_ok
            )

            if search_results:
                st.success(f"✅ Found {len(search_results)} opportunities backed by ai_data corpora")
            else:
                st.warning("No roles matched your filters in the current ai_data slice. Try widening skills or titles.")

            st.session_state.umarketu_state['search_results'] = search_results
            st.session_state.umarketu_state['last_search_completed_at'] = datetime.now().isoformat()
            persist_umarketu_state(user_id)

    # Email integration enhancement for job search
    if EMAIL_INTEGRATION_AVAILABLE and email_bridge:
        display_email_enhancement_options("job_search")

    # Display search results
    if st.session_state.umarketu_state['search_results']:
        st.markdown("### 📋 Search Results")

        # Sort options
        sort_by = st.selectbox("Sort by", ["Quick Fit Score ⬇️", "Salary ⬇️", "Posted Date ⬇️"], index=0)

        def _parse_posted(job_payload: Dict[str, Any]) -> float:
            value = str(job_payload.get('posted') or '')
            try:
                return datetime.fromisoformat(value.replace('Z', '')).timestamp()
            except Exception:
                return 0.0

        results = st.session_state.umarketu_state['search_results']
        if sort_by == "Quick Fit Score ⬇️":
            results = sorted(results, key=lambda job: job.get('quick_fit', 0), reverse=True)
        elif sort_by == "Salary ⬇️":
            results = sorted(results, key=lambda job: job.get('salary_min') or 0, reverse=True)
        elif sort_by == "Posted Date ⬇️":
            results = sorted(results, key=_parse_posted, reverse=True)

        for job in results:
            with st.container():
                col1, col2, col3, col4 = st.columns([3, 1, 1, 1])

                with col1:
                    st.markdown(f"### {job['title']}")
                    st.markdown(f"**{job['company']}** | 📍 {job['location']} | {job['remote']}")
                    st.markdown(f"💰 {job['salary']} | 📅 Posted {job['posted']} | Source: {job['source']}")

                with col2:
                    # Quick fit indicator
                    fit_color = "green" if job['quick_fit'] >= 80 else "orange" if job['quick_fit'] >= 60 else "red"
                    st.markdown(f"### :{fit_color}[{job['quick_fit']}%]")
                    st.caption("Quick Fit")

                with col3:
                    # Application Blocker Badge - Calculate from real JD data
                    if BLOCKER_ENGINE_AVAILABLE and job.get('jd_data'):
                        jd_data = job.get('jd_data', {})
                        required_skills = jd_data.get('required_skills', [])

                        # Calculate real blocker count
                        blocker_count = 0
                        if required_skills:
                            missing_skills = [s for s in required_skills if s.lower() not in [sk.lower() for sk in search_skills]]
                            blocker_count = len(missing_skills)

                        # Experience blocker
                        min_exp = jd_data.get('min_experience_years', 0)
                        user_exp = st.session_state.get('user_experience_years', 0)
                        if min_exp > user_exp:
                            blocker_count += 1

                        # Education blocker
                        required_degree = jd_data.get('required_education', '')
                        user_education = st.session_state.get('user_education_level', '')
                        if required_degree and not user_education:
                            blocker_count += 1

                        if blocker_count == 0:
                            st.success("✅ Strong Match")
                            st.caption("No blockers")
                        elif blocker_count <= 2:
                            st.warning(f"⚠️ {blocker_count} Blocker{'s' if blocker_count > 1 else ''}")
                            st.caption("Addressable")
                        else:
                            st.error(f"🚧 {blocker_count} Blockers")
                            st.caption("Multiple gaps")

                        if st.button("🚧 Details", key=f"blocker_{job['id']}", use_container_width=True):
                            # Navigate to Application Blockers page with job_id
                            st.session_state['blocker_job_id'] = job['id']
                            st.session_state['blocker_job_title'] = job['title']
                            st.switch_page("pages/16_Application_Blockers.py")
                    else:
                        st.caption("Blocker analysis\nunavailable")

                with col4:
                    if st.button("📊 Analyze Fit", key=f"analyze_{job['id']}", use_container_width=True):
                        st.session_state.umarketu_state['selected_job'] = job
                        st.session_state.umarketu_state['current_step'] = 'fit'
                        persist_umarketu_state(user_id)

                        # Enhanced fit analysis with email integration
                        if EMAIL_INTEGRATION_AVAILABLE and email_bridge:
                            try:
                                user_email = st.session_state.get("user_email")
                                job_enhancement = email_bridge.enhance_job_application_with_email_data(job, user_email)
                                st.session_state.umarketu_state['email_enhancement'] = job_enhancement

                                if job_enhancement.get("company_contacts"):
                                    st.success(f"📧 Found {len(job_enhancement['company_contacts'])} contacts at {job['company']}")
                            except Exception as e:
                                st.warning(f"⚠️ Email enhancement failed: {e}")

                        st.rerun()

                    if st.button("🔗 View Job", key=f"view_{job['id']}", use_container_width=True):
                        st.markdown(f"[Open in new tab]({job['url']})")

                # Web intelligence enhancement for each job
                if WEB_INTELLIGENCE_AVAILABLE:
                    with st.expander(f"🌐 Company Research - {job['company']}", expanded=False):
                        display_web_intelligence_enhancement("job_search",
                                                           company_name=job['company'],
                                                           job_title=job['title'])

                # Job Title Intelligence enhancement for role analysis
                if JOB_TITLE_INTELLIGENCE_AVAILABLE:
                    with st.expander(f"🎯 Role Intelligence - {job['title']}", expanded=False):
                        col1, col2 = st.columns(2)

                        live_current_role = profile_data.get('current_role')
                        if not live_current_role:
                            latest_experience = (resume_snapshot.get('experience') or resume_snapshot.get('work_experience') or [])
                            if latest_experience:
                                first_role = latest_experience[0]
                                if isinstance(first_role, dict):
                                    live_current_role = first_role.get('title') or first_role.get('role')
                        if not live_current_role:
                            live_current_role = analysis_results.get('current_role') or ""

                        live_skills = extract_resume_skills(resume_snapshot)
                        if not live_skills:
                            if isinstance(profile_data.get('skills'), list):
                                live_skills = profile_data['skills']
                            elif profile_data.get('skills'):
                                live_skills = [profile_data['skills']]
                            else:
                                live_skills = analysis_results.get('tech_keywords', []) or []

                        live_experience_years = get_resume_experience_years(resume_snapshot) or profile_data.get('experience_years') or analysis_results.get('experience_years')

                        live_user_profile = {
                            'current_role': live_current_role,
                            'skills': live_skills,
                            'experience_years': live_experience_years
                        }

                        if not (live_user_profile['current_role'] or live_user_profile['skills']):
                            st.info("📄 Upload your resume (page 09) to unlock personalized role intelligence")

                        if not job_title_bridge:
                            st.warning("Role intelligence service is currently offline")
                            continue

                        with col1:
                            if st.button("📈 Analyze Role Fit", key=f"role_fit_{job['id']}", type="secondary"):
                                with st.spinner("Analyzing role fit..."):
                                    context = (
                                        f"skills={','.join(live_user_profile.get('skills', [])[:5])};"
                                        f"experience={live_user_profile.get('experience_years', 'n/a')}"
                                    )
                                    role_analysis = job_title_bridge.analyze_job_title(job['title'], context=context) or {}

                                    st.success("🎯 Role Fit Analysis Complete")
                                    st.metric("Confidence", f"{role_analysis.get('confidence_score', 0.7)*100:.0f}%")
                                    summary = (
                                        role_analysis.get('analysis')
                                        or role_analysis.get('ai_analysis', {}).get('predicted_category')
                                        or "Good potential match"
                                    )
                                    st.markdown(f"**Analysis:** {summary}")

                                    strengths = role_analysis.get('key_strengths') or role_analysis.get('ai_recommendations', {}).get('skill_gaps')
                                    if strengths:
                                        st.markdown("**Focus Areas:**")
                                        for strength in strengths[:5]:
                                            st.markdown(f"• {strength}")

                        with col2:
                            if st.button("🚀 Career Path Analysis", key=f"career_path_{job['id']}", type="secondary"):
                                with st.spinner("Analyzing career progression..."):
                                    user_role = live_user_profile.get('current_role', 'Professional')
                                    career_paths = job_title_bridge.get_career_pathways(current_role=user_role) or []

                                    st.success("🚀 Career Path Analysis Complete")
                                    if isinstance(career_paths, list) and career_paths:
                                        top_path = career_paths[0]
                                        st.markdown(f"**Track:** {top_path.get('pathway_type', 'Progression')} ({top_path.get('timeline', '2-4 years')})")
                                        roles = top_path.get('roles') or []
                                        for idx, role in enumerate(roles[:4], 1):
                                            st.markdown(f"{idx}. {role}")
                                        st.caption(f"Confidence: {top_path.get('confidence', 0.7):.0%} | Source: {top_path.get('data_source', 'ai_engine')}")
                                    else:
                                        st.info("Career pathway suggestions unavailable right now")

                st.markdown("---")

# ===========================
# TAB 2: FIT ANALYSIS
# ===========================
with tab2:
    st.header("📊 Fit Analysis - Touch Points & Block Points")
    st.markdown("**US3**: Calculate Touch-Points (positives) and Block-Points (gaps), output % fit, suggest actions")

    selected_job = st.session_state.umarketu_state.get('selected_job')

    if not selected_job:
        st.info("👈 Select a job from the Discovery tab to analyze fit")
    else:
        st.success(f"**Analyzing**: {selected_job['title']} at {selected_job['company']}")

        # JD ingestion (US2)
        with st.expander("📄 Job Description Details", expanded=False):
            st.markdown("**Auto-captured from job posting**")

            # Simulated JD text
        # Display real JD from job data
        if selected_job.get('jd_data'):
            jd_data = selected_job['jd_data']

            jd_text = f"""**{selected_job['title']}** at {selected_job['company']}

**Requirements:**
{chr(10).join('- ' + skill for skill in jd_data.get('required_skills', []))}

**Experience:** {jd_data.get('min_experience_years', 'Not specified')} years

**Education:** {jd_data.get('required_education', 'Not specified')}

**Responsibilities:**
{chr(10).join('- ' + resp for resp in jd_data.get('responsibilities', [])[:5])}
"""
            st.text_area("JD Text", jd_text, height=200)
        else:
            st.warning("⚠️ Job description data not available for this listing.")
            st.text_area("JD Text", f"**{selected_job['title']}** at {selected_job['company']}\n\nFull JD available at company website.", height=200)

        # Fit analysis engine
        if st.button("🔍 Calculate Fit Score", type="primary"):
            resume_snapshot = extract_resume_snapshot()
            if not resume_snapshot:
                st.error("❌ Cannot analyze without your resume data")
                st.info("🔗 Please upload your resume in the Resume Upload & Analysis page first")
                if st.button("🎯 Go to Resume Upload", key="fit_upload_nav"):
                    st.switch_page("pages/09_Resume_Upload_Analysis.py")
                st.stop()

            with st.spinner("🧠 Analyzing with your parsed resume data..."):
                resume_skills = [skill.lower() for skill in extract_resume_skills(resume_snapshot)]
                resume_experience_years = get_resume_experience_years(resume_snapshot)
                education_entries = (
                    resume_snapshot.get('education')
                    or resume_snapshot.get('education_history')
                    or []
                )
                highest_degree = ''
                if education_entries:
                    first_entry = education_entries[0]
                    if isinstance(first_entry, dict):
                        highest_degree = first_entry.get('degree') or first_entry.get('qualification') or ''
                    else:
                        highest_degree = str(first_entry)

                jd_data = selected_job.get('jd_data', {})
                required_skills = jd_data.get('required_skills', [])
                min_experience = jd_data.get('min_experience_years', 0)
                required_education = jd_data.get('required_education', '')

                touch_points: List[Dict[str, Any]] = []
                for req_skill in required_skills:
                    normalized = req_skill.lower()
                    if normalized in resume_skills:
                        touch_points.append({
                            'skill': req_skill,
                            'weight': 'Core' if normalized in resume_skills[:5] else 'Supporting',
                            'evidence': 'Resume keyword match'
                        })

                block_points: List[Dict[str, Any]] = []
                for req_skill in required_skills:
                    normalized = req_skill.lower()
                    if normalized not in resume_skills:
                        block_points.append({
                            'requirement': req_skill,
                            'gap': 'Skill not highlighted in resume',
                            'severity': 'High' if 'required' in normalized else 'Medium',
                            'solution': f'Add quantified example referencing {req_skill}'
                        })

                if min_experience and resume_experience_years < min_experience:
                    block_points.append({
                        'requirement': f'{min_experience}+ years experience',
                        'gap': f"Documented {resume_experience_years:.1f} years",
                        'severity': 'Medium',
                        'solution': 'Elevate leadership scope and measurable impact to offset the gap'
                    })

                if required_education:
                    if not highest_degree:
                        block_points.append({
                            'requirement': required_education,
                            'gap': 'Education history not found in resume snapshot',
                            'severity': 'Medium',
                            'solution': 'Surface degree or equivalent certifications in the education section'
                        })
                    elif required_education.lower() not in highest_degree.lower():
                        block_points.append({
                            'requirement': required_education,
                            'gap': highest_degree,
                            'severity': 'Medium',
                            'solution': 'Reference equivalent credentials or professional certifications'
                        })

                skill_share = len(touch_points) / len(required_skills) if required_skills else 0.5
                experience_fit = min(resume_experience_years / max(min_experience, 1), 1) if min_experience else 1
                education_fit = 1 if not required_education or (highest_degree and required_education.lower() in highest_degree.lower()) else 0.6
                fit_score = int((skill_share * 60) + (experience_fit * 25) + (education_fit * 15))

                st.session_state.umarketu_state['fit_analysis'] = {
                    'fit_score': fit_score,
                    'touch_points': touch_points,
                    'block_points': block_points,
                    'resume_experience_years': resume_experience_years,
                    'required_experience': min_experience,
                    'required_skills': required_skills,
                    'required_education': required_education
                }
                st.success("✅ Resume-aligned fit analysis complete!")
                persist_umarketu_state(user_id)

        # Display fit analysis
        if st.session_state.umarketu_state.get('fit_analysis'):
            analysis = st.session_state.umarketu_state['fit_analysis']
            fit_score = analysis['fit_score']
            touch_count = len(analysis['touch_points'])
            block_count = len(analysis['block_points'])
            required_count = len(analysis.get('required_skills') or [])
            skill_coverage = int((touch_count / required_count) * 100) if required_count else 0

            # Overall score
            st.markdown("### 🎯 Overall Fit Score")
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                color = "green" if fit_score >= 75 else "orange" if fit_score >= 60 else "red"
                st.markdown(f"# :{color}[{fit_score}%]")
                st.caption("Match Score")
            with col2:
                st.metric("Touch Points", touch_count, help="Strengths matching requirements")
                if required_count:
                    st.caption(f"{skill_coverage}% of JD requirements covered")
            with col3:
                st.metric("Block Points", block_count, help="Gaps to address")
            with col4:
                likelihood = "Strong Bet" if fit_score >= 75 else "Competitive" if fit_score >= 60 else "Stretch"
                st.markdown(f"### {likelihood}")
                st.caption("Likelihood Band")

            # Touch Points (strengths)
            st.markdown("### ✅ Touch Points - Your Strengths")
            if analysis['touch_points']:
                tp_rows = [{
                    'Skill': tp.get('skill', 'Requirement'),
                    'Weight': tp.get('weight', 'Core'),
                    'Evidence': tp.get('evidence', 'Resume keyword match')
                } for tp in analysis['touch_points']]
                st.dataframe(pd.DataFrame(tp_rows), use_container_width=True)
            else:
                st.info("No direct keyword matches yet. Add targeted skills or impact metrics to your resume summary.")

            # Block Points (gaps)
            st.markdown("### ⚠️ Block Points - Gaps to Address")
            if analysis['block_points']:
                for bp in analysis['block_points']:
                    severity = (bp.get('severity') or 'medium').lower()
                    severity_badge = "🔴 High" if severity == 'high' else "🟡 Medium"
                    st.markdown(f"{severity_badge} **{bp.get('requirement', 'Requirement')}** — {bp.get('gap', 'Gap detected')}")
                    st.info(f"💡 **Mitigation**: {bp.get('solution', 'Add concrete accomplishment that proves this capability.')}")
            else:
                st.success("No blocking requirements detected 🎉")

            # Quadrant visualization
            st.markdown("### 📈 Value vs Readiness Quadrant")

            fig = go.Figure()

            # Add quadrant background
            fig.add_shape(type="rect", x0=0, y0=0, x1=50, y1=50, fillcolor="lightcoral", opacity=0.2, line_width=0)
            fig.add_shape(type="rect", x0=50, y0=0, x1=100, y1=50, fillcolor="lightyellow", opacity=0.2, line_width=0)
            fig.add_shape(type="rect", x0=0, y0=50, x1=50, y1=100, fillcolor="lightyellow", opacity=0.2, line_width=0)
            fig.add_shape(type="rect", x0=50, y0=50, x1=100, y1=100, fillcolor="lightgreen", opacity=0.2, line_width=0)

            # Add current position
            readiness = skill_coverage or fit_score
            resume_experience_years = analysis.get('resume_experience_years', 0)
            required_experience = analysis.get('required_experience') or 0
            experience_ratio = min(resume_experience_years / max(required_experience, 1), 1) if required_experience else 1
            value = int(min(100, (fit_score * 0.7) + (experience_ratio * 30)))
            fig.add_trace(go.Scatter(
                x=[readiness],
                y=[value],
                mode='markers+text',
                marker=dict(size=20, color='blue'),
                text=['YOU'],
                textposition='top center',
                name='Your Position'
            ))

            fig.update_layout(
                title="Your Position in Value-Readiness Space",
                xaxis_title="Readiness (Skills & Recency) →",
                yaxis_title="Value to Employer →",
                xaxis=dict(range=[0, 100]),
                yaxis=dict(range=[0, 100]),
                height=400
            )

            st.plotly_chart(fig, use_container_width=True)

            # US4: Peer Overlay
            st.markdown("### 👥 Peer Comparison Overlay")
            if st.button("📊 Show Peer Benchmarking"):
                if not (USER_DATA_SERVICE_AVAILABLE and user_data_service):
                    st.warning("Peer data service is offline right now.")
                else:
                    with st.spinner("🔄 Building peer cohort from live profiles..."):
                        overlay = build_peer_overlay(selected_job, fit_score, user_id)
                        if overlay:
                            st.session_state.umarketu_state['peer_overlay'] = overlay
                            persist_umarketu_state(user_id)
                        else:
                            st.warning("Peer benchmarking not available for this role yet.")

            if st.session_state.umarketu_state.get('peer_overlay'):
                overlay = st.session_state.umarketu_state['peer_overlay']

                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Your Rank", overlay['rank'])
                with col2:
                    st.metric("Percentile", f"{overlay['percentile']}th")
                with col3:
                    st.metric("Cohort Average", f"{overlay['avg_fit']}%")
                with col4:
                    st.metric("Top 10% Threshold", f"{overlay['top_10_fit']}%")

                st.success(f"✅ You rank in the **{overlay['rank']}** among {overlay['cohort_size']} similar candidates")

                if overlay.get('distribution'):
                    dist_fig = go.Figure(data=[go.Histogram(
                        x=overlay['distribution'],
                        nbinsx=10,
                        marker_color="#4c78ff",
                        opacity=0.7
                    )])
                    dist_fig.add_vline(x=fit_score, line_dash="dash", line_color="#ff7f0e", annotation_text="You", annotation_position="top right")
                    dist_fig.update_layout(
                        title="Fit Score Distribution",
                        xaxis_title="Fit Score",
                        yaxis_title="Peer Count",
                        bargap=0.1,
                        height=320
                    )
                    st.plotly_chart(dist_fig, use_container_width=True)

                if overlay.get('sample'):
                    st.markdown("#### Sample Peer Profiles")
                    sample_df = pd.DataFrame(overlay['sample'])
                    st.dataframe(sample_df, use_container_width=True)

        # Email enhancement data for fit analysis
        if EMAIL_INTEGRATION_AVAILABLE and st.session_state.umarketu_state.get('email_enhancement'):
            enhancement = st.session_state.umarketu_state['email_enhancement']

            st.markdown("### 📧 Email-Based Application Intelligence")

            col1, col2 = st.columns(2)

            with col1:
                st.markdown("#### 👥 Company Contacts Found")
                if enhancement.get('company_contacts'):
                    for contact in enhancement['company_contacts']:
                        st.info(f"👤 **{contact.get('name', 'Unknown')}** - {contact.get('role', 'Unknown Role')} (Connection: {contact.get('connection_strength', 'Unknown')})")
                else:
                    st.info("No direct company contacts found in email history")

            with col2:
                st.markdown("#### 📈 Application History")
                if enhancement.get('application_history'):
                    for app in enhancement['application_history']:
                        st.warning(f"📅 **{app.get('date', 'Unknown')}**: Applied for {app.get('position', 'Unknown Position')} - Status: {app.get('status', 'Unknown')}")
                else:
                    st.success("No previous applications to this company found")

            if enhancement.get('networking_path'):
                st.markdown("#### 🤝 Suggested Networking Paths")
                for path in enhancement['networking_path']:
                    st.markdown(f"• **{path.get('path', 'Unknown Path')}** (Strength: {path.get('strength', 'Unknown')})")

            if st.button("🔄 Refresh Email Enhancement Data"):
                st.rerun()

# ===========================
# TAB 3: RESUME TUNING
# ===========================
with tab3:
    st.header("📝 Resume Auto-Tuning")
    st.markdown("**US5**: Generate role-specific resume variant, highlighting strengths and closing gaps with evidence")

    if not st.session_state.umarketu_state.get('selected_job'):
        st.info("👈 Select a job and analyze fit first")
    elif not st.session_state.umarketu_state.get('fit_analysis'):
        st.info("👆 Run fit analysis first to get tuning recommendations")
    else:
        job = st.session_state.umarketu_state['selected_job']
        fit = st.session_state.umarketu_state['fit_analysis']

        st.success(f"**Tuning resume for**: {job['title']} at {job['company']}")

        # Tuning options
        col1, col2 = st.columns(2)
        with col1:
            headline_style = st.selectbox(
                "📰 Headline Style",
                ["Achievement-focused", "Skill-focused", "Impact-focused", "Hybrid"],
                index=0
            )

            bullet_format = st.selectbox(
                "📋 Bullet Format",
                ["STAR (Situation-Task-Action-Result)", "CAR (Context-Action-Result)", "PAR (Problem-Action-Result)"],
                index=0
            )

        with col2:
            skills_placement = st.selectbox(
                "🎯 Skills Section",
                ["Top (before experience)", "Bottom (after experience)", "Integrated in bullets"],
                index=0
            )

            gap_strategy = st.multiselect(
                "🔧 Gap Mitigation Strategy",
                ["Include micro-courses", "Add portfolio links", "Highlight transferable skills", "Add case notes"],
                default=["Highlight transferable skills"]
            )

        tuning_options = {
            "headline_style": headline_style,
            "bullet_format": bullet_format,
            "skills_placement": skills_placement,
            "gap_strategy": gap_strategy,
        }

        # Generate tuned resume
        if st.button("✨ Generate Tailored Resume", type="primary"):
            resume_snapshot = extract_resume_snapshot()
            if not resume_snapshot:
                st.error("❌ Upload or import your resume first")
            else:
                with st.spinner("🎨 Auto-tuning your resume..."):
                    tuned_resume = generate_tuned_resume(resume_snapshot, job, fit, tuning_options)
                    st.session_state.umarketu_state['tuned_resume'] = tuned_resume
                    st.success("✅ Resume variant generated from your latest upload!")
                    persist_umarketu_state(user_id)

        # Display tuned resume
        if st.session_state.umarketu_state.get('tuned_resume'):
            tuned = st.session_state.umarketu_state['tuned_resume']

            st.markdown("### 📄 Tailored Resume Preview")

            # Show changes summary
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Changes Made", tuned['changes'])
            with col2:
                st.metric("Version ID", tuned['version_id'])
            with col3:
                st.metric("ATS Projection", f"{tuned.get('ats_projection', 90)}%")

            # Diff viewer (simplified)
            with st.expander("🔍 View Changes", expanded=True):
                col1, col2 = st.columns(2)

                with col1:
                    st.markdown("#### ❌ Original")
                    st.code(f"""
Headline: {tuned.get('original_headline', 'Master Resume')}

Summary: {tuned.get('original_summary', 'No summary detected in upload.')}
""", language="markdown")

                with col2:
                    st.markdown("#### ✅ Tailored")
                    updated_experience = "\n".join(f"- {bullet}" for bullet in tuned.get('bullets', [])) or "- Pending experience alignment"
                    st.code(f"""
Headline: {tuned['headline']}

Summary: {tuned['summary']}

Experience:
{updated_experience}
""", language="markdown")

            st.markdown("### 🎯 Emphasis Plan")
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("**Skills to Highlight**")
                for skill in tuned.get('skills_to_emphasize', []):
                    st.markdown(f"• {skill}")
            with col2:
                st.markdown("**Gaps to Close**")
                if tuned.get('gaps_to_close'):
                    for gap in tuned['gaps_to_close']:
                        st.markdown(f"• Address {gap}")
                else:
                    st.markdown("• All JD gaps addressed")

            # Export options
            st.markdown("### 💾 Export Resume")
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                if st.button("📥 Download PDF", use_container_width=True):
                    st.info("🔄 Generating PDF...")
            with col2:
                if st.button("📥 Download DOCX", use_container_width=True):
                    st.info("🔄 Generating DOCX...")
            with col3:
                if st.button("📋 Copy to Clipboard", use_container_width=True):
                    st.success("✅ Copied!")
            with col4:
                if st.button("🚀 Apply with This Resume", use_container_width=True):
                    # Show email draft generation options
                    st.session_state.umarketu_state['show_email_draft'] = True
                    st.rerun()

        # Email Draft Generation Modal
        if st.session_state.umarketu_state.get('show_email_draft', False):
            with st.expander("📧 Generate Application Email", expanded=True):
                st.markdown("### 📝 Professional Application Email Generator")
                st.info("💡 We'll generate a professional email draft that you copy and send from your own email client")

                contact_email = st.session_state.umarketu_state.get('draft_contact_email', '')
                hiring_manager = st.session_state.umarketu_state.get('draft_hiring_manager', '')
                additional_message = st.session_state.umarketu_state.get('draft_additional_message', '')

                col1, col2 = st.columns([2, 1])

                current_job = st.session_state.umarketu_state.get('selected_job')

                with col1:
                    st.markdown("#### Email Details")

                    default_email = (current_job.get('contact_email') if current_job else None) or contact_email
                    contact_email = st.text_input(
                        "📧 Hiring Manager Email",
                        value=default_email,
                        placeholder="hr@company.com"
                    ).strip()
                    st.session_state.umarketu_state['draft_contact_email'] = contact_email

                    default_manager = (current_job.get('hiring_manager') if current_job else None) or hiring_manager
                    hiring_manager = st.text_input(
                        "👤 Hiring Manager Name",
                        value=default_manager,
                        placeholder="Hiring Manager"
                    ).strip()
                    st.session_state.umarketu_state['draft_hiring_manager'] = hiring_manager

                    additional_message = st.text_area(
                        "💬 Personal Message (Optional)",
                        value=additional_message,
                        placeholder="Add a personalized message to stand out...",
                        height=60
                    )
                    st.session_state.umarketu_state['draft_additional_message'] = additional_message

                with col2:
                    st.markdown("#### Quick Preview")

                    if contact_email and current_job:
                        user_profile = st.session_state.get('user_profile', {}) or {}
                        full_name = user_profile.get('name') or profile_data.get('first_name') or "Candidate"
                        st.markdown(f"**To**: {contact_email}")
                        st.markdown(f"**Subject**: Application for {current_job.get('title', 'Position')} - {full_name}")

                        if hiring_manager:
                            st.markdown(f"**Greeting**: Dear {hiring_manager}")
                    elif contact_email:
                        st.markdown(f"**To**: {contact_email}")
                        st.info("Select a role from Discovery to personalize the subject line")
                    else:
                        st.info("📧 Enter email details above")

                # Generate draft button
                if st.button("✨ Generate Professional Email Draft", type="primary", use_container_width=True):
                    if not current_job:
                        st.error("❌ Select a job first so we can personalize the email")
                    elif not contact_email:
                        st.error("❌ Enter a hiring manager email")
                    elif not (EMAIL_SERVICE_AVAILABLE and email_service):
                        st.error("❌ Email service not available in this environment")
                    else:
                        job_data = {
                            'title': current_job.get('title', 'Position'),
                            'company': current_job.get('company', 'Company'),
                            'contact_email': contact_email,
                            'hiring_manager': hiring_manager or 'Hiring Manager'
                        }

                        user_profile = st.session_state.get('user_profile', {}) or {}
                        if not user_profile:
                            user_profile = {
                                'full_name': profile_data.get('first_name', 'Candidate'),
                                'email': profile_data.get('email', ''),
                                'phone': profile_data.get('phone', ''),
                                'skills': resume_skills,
                                'achievements': []
                            }

                        with st.spinner("✨ Generating professional email draft..."):
                            try:
                                draft = email_service.generate_job_application_draft(
                                    job_data=job_data,
                                    user_profile=user_profile,
                                    additional_message=additional_message
                                )

                                st.session_state.umarketu_state['generated_draft'] = draft
                                st.session_state.umarketu_state['generated_draft_meta'] = {
                                    'job_title': job_data['title'],
                                    'company': job_data['company'],
                                    'contact_email': contact_email,
                                    'resume_version': st.session_state.umarketu_state.get('tuned_resume', {}).get('version_id') or "Tailored",
                                    'additional_message': additional_message
                                }
                                st.success("✅ Professional email draft generated!")

                            except Exception as e:
                                st.error(f"❌ Draft generation error: {str(e)}")

                # Display generated draft
                if st.session_state.umarketu_state.get('generated_draft'):
                    draft = st.session_state.umarketu_state['generated_draft']
                    draft_meta = st.session_state.umarketu_state.get('generated_draft_meta', {})

                    st.markdown("---")
                    st.markdown("### 📨 Your Professional Email Draft")

                    # Email details
                    col1, col2 = st.columns(2)
                    with col1:
                        st.text_input("📧 To:", value=draft['to_email'], disabled=True)
                        st.text_input("📝 Subject:", value=draft['subject'], disabled=True)
                    with col2:
                        st.info(draft['attachment_guidance'])

                    # Email body
                    email_body = st.text_area(
                        "📄 Email Body (Copy this):",
                        value=draft['body'],
                        height=300,
                        help="Copy this text and paste into your email client"
                    )

                    # Action buttons
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        if st.button("📋 Copy Email Body", use_container_width=True):
                            st.success("✅ Email copied to clipboard!")
                            st.info("💡 Now paste into your email client and send")

                            draft_company = draft_meta.get('company')
                            draft_job = draft_meta.get('job_title')
                            if draft_company and draft_job:
                                application = {
                                    'id': f"app_{int(datetime.now().timestamp())}",
                                    'job_title': draft_job,
                                    'company': draft_company,
                                    'contact_email': draft_meta.get('contact_email'),
                                    'date_applied': datetime.now().strftime("%Y-%m-%d"),
                                    'status': 'Draft Generated',
                                    'method': 'Email Draft',
                                    'resume_version': draft_meta.get('resume_version', 'Tailored'),
                                    'additional_notes': draft_meta.get('additional_message', additional_message)
                                }

                                st.session_state.umarketu_state.setdefault('applications', []).append(application)
                                if STATE_BRIDGE_AVAILABLE and user_id:
                                    save_applications(user_id, st.session_state.umarketu_state['applications'])
                                    persist_umarketu_state(user_id)
                            else:
                                st.warning("Generate a draft again to log it into the tracker")

                    with col2:
                        # Generate mailto link for direct email client opening
                        mailto_link = draft.get('mailto_link', '#')
                        st.link_button("📧 Open in Email Client", mailto_link, use_container_width=True)

                    with col3:
                        if st.button("💾 Save Draft", use_container_width=True):
                            st.info("📝 Draft saved for later use")

                # Close button
                if st.button("❌ Close", use_container_width=True):
                    st.session_state.umarketu_state['show_email_draft'] = False
                    st.session_state.umarketu_state['generated_draft'] = None
                    st.rerun()# ===========================
# TAB 4: APPLICATION TRACKER
# ===========================
with tab4:
    st.header("📋 Application Tracker")
    st.markdown("**US7**: Log every application with structured fields; link to resume version sent")

    # Quick stats
    applications = st.session_state.umarketu_state.get('applications', [])
    total_apps = len(applications)
    status_strings = [str(app.get('status', '')).lower() for app in applications]
    interview_total = sum(1 for status in status_strings if 'interview' in status)
    offer_total = sum(1 for status in status_strings if 'offer' in status)
    in_progress_total = sum(1 for status in status_strings if any(token in status for token in ['applied', 'screen', 'interview']))
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Applications", total_apps)
    with col2:
        st.metric("In Progress", in_progress_total)
    with col3:
        st.metric("Interviews", interview_total)
    with col4:
        st.metric("Offers", offer_total)

    # Add new application
    with st.expander("➕ Add New Application", expanded=False):
        col1, col2 = st.columns(2)

        with col1:
            app_company = st.text_input("Company")
            app_title = st.text_input("Job Title")
            app_location = st.text_input("Location")
            app_salary = st.text_input("Salary Range")

        with col2:
            app_status = st.selectbox("Status", ["Applied", "Phone Screen", "Interview", "Offer", "Rejected", "Withdrawn"])
            app_applied_date = st.date_input("Applied Date", datetime.now())
            app_contact_name = st.text_input("Contact Name")
            app_contact_email = st.text_input("Contact Email")

        resume_version_candidates: List[str] = []
        if resume_snapshot:
            primary_label = (
                resume_snapshot.get('metadata', {}).get('version_label')
                or resume_snapshot.get('metadata', {}).get('file_name')
                or "Uploaded Resume"
            )
            resume_version_candidates.append(primary_label)

        tuned_resume = st.session_state.umarketu_state.get('tuned_resume')
        if tuned_resume:
            resume_version_candidates.append(tuned_resume.get('version_id') or "Tailored Resume")

        resume_version_candidates.extend([
            str(app.get('resume_version'))
            for app in applications
            if app.get('resume_version')
        ])

        seen_versions = set()
        resume_version_options = []
        for version in resume_version_candidates:
            if not version or version in seen_versions:
                continue
            seen_versions.add(version)
            resume_version_options.append(version)

        if resume_version_options:
            app_resume_version = st.selectbox("Resume Version Used", resume_version_options)
        else:
            st.info("📄 Upload a resume (page 09) or generate a tailored version to tag applications")
            app_resume_version = ""

        app_notes = st.text_area("Notes", placeholder="Additional details, follow-up actions, etc.")

        if st.button("💾 Save Application", type="primary"):
            if not app_company or not app_title:
                st.error("❌ Company and Job Title are required")
            else:
                applications = st.session_state.umarketu_state.setdefault('applications', [])
                new_application = {
                    'id': str(uuid4()),
                    'company': app_company.strip(),
                    'job_title': app_title.strip(),
                    'location': app_location.strip(),
                    'salary_range': app_salary.strip(),
                    'status': app_status,
                    'date_applied': app_applied_date.strftime("%Y-%m-%d"),
                    'contact_name': app_contact_name.strip(),
                    'contact_email': app_contact_email.strip(),
                    'resume_version': app_resume_version,
                    'notes': app_notes.strip(),
                    'source': 'Manual Entry',
                    'timeline': []
                }

                try:
                    append_timeline_event(new_application, datetime.combine(app_applied_date, datetime.min.time()), "Applied", "Logged via tracker")
                except Exception:
                    pass

                applications.append(new_application)
                if STATE_BRIDGE_AVAILABLE and user_id:
                    save_applications(user_id, applications)
                    persist_umarketu_state(user_id)
                st.success("✅ Application logged!")
                st.session_state.umarketu_state['_applications_loaded'] = True
                st.rerun()

    # Applications table
    st.markdown("### 📊 Your Applications")
    if applications:
        apps_data = []
        for app in applications:
            apps_data.append({
                'Company': app.get('company', ''),
                'Title': app.get('job_title', app.get('title', '')),
                'Location': app.get('location', ''),
                'Status': app.get('status', 'Unknown'),
                'Applied': app.get('date_applied', ''),
                'Last Update': app.get('last_update') or app.get('date_applied', ''),
                'Resume': app.get('resume_version', ''),
                'Next Action': app.get('next_action', ''),
                'Notes': app.get('notes', app.get('additional_notes', ''))
            })
        df_apps = pd.DataFrame(apps_data)
        st.dataframe(df_apps, use_container_width=True, height=300)
    else:
        st.info("📝 No applications yet. Add your first application above!")
        df_apps = pd.DataFrame()

    # Application timeline (for selected application)
    st.markdown("### 📅 Application Timeline")
    if applications:
        indices = list(range(len(applications)))
        selected_idx = st.selectbox(
            "Select application to view timeline",
            indices,
            format_func=lambda idx: f"{applications[idx].get('job_title', applications[idx].get('title', 'Role'))} at {applications[idx].get('company', 'Company')}"
        )
        active_app = applications[selected_idx]
        timeline_data = active_app.get('timeline', [])
        if timeline_data:
            df_timeline = pd.DataFrame(timeline_data)
            st.dataframe(df_timeline, use_container_width=True)
        else:
            st.info("No timeline events yet for this application")

        col1, col2, col3 = st.columns(3)
        with col1:
            if st.button("🎤 Prepare Interview", use_container_width=True):
                st.session_state.umarketu_state['current_step'] = 'coach'
                st.session_state.umarketu_state['selected_application_for_coach'] = active_app.get('id')
                st.rerun()
        with col2:
            if st.button("📧 Draft Follow-up", use_container_width=True):
                st.info("📝 Opening outreach assistant...")
        with col3:
            if st.button("📝 Update Status", use_container_width=True):
                st.info("✏️ Status editor coming soon")
    else:
        st.info("Add an application to unlock the timeline view")

# ===========================
# TAB 5: INTERVIEW COACH
# ===========================
with tab5:
    st.header("🎤 Interview Coach")
    st.markdown("**US8**: Get tailored Q&A pack, company intel, timeline prep, behavior/mindset tips")

    # Select job or standalone
    coach_mode = st.radio(
        "Interview Mode",
        ["📋 Linked to Application", "🆕 Standalone Prep"],
        horizontal=True
    )

    linked_application = None
    role_input_value: Optional[str] = None
    company_input_value: Optional[str] = None
    if coach_mode == "📋 Linked to Application":
        if applications:
            option_indices = list(range(len(applications)))
            option_labels = [
                f"{applications[i].get('job_title', applications[i].get('title', 'Role'))} at {applications[i].get('company', 'Company')}"
                for i in option_indices
            ]
            selected_idx = st.selectbox(
                "Select Application",
                option_indices,
                format_func=lambda idx: option_labels[idx]
            )
            linked_application = applications[selected_idx]
            st.success(f"✅ Loading interview prep for: **{option_labels[selected_idx]}**")
            st.info("💡 Using fit analysis and resume variant to generate talking points")
        else:
            st.info("📝 Add applications in the Application Tracker tab to use this feature")
    else:
        company_input = st.text_input("Company Name", placeholder="Enter company name", key="interview_company_input")
        role_input = st.text_input("Role Title", placeholder="e.g., Senior ML Engineer", key="interview_role_input")
        company_input_value = company_input.strip() if company_input else None
        role_input_value = role_input.strip() if role_input else None

    # Generate interview pack
    if st.button("🎯 Generate Interview Pack", type="primary"):
        with st.spinner("🧠 Preparing your interview pack..."):
            # Get company name from selection or input
            company_name = None
            role_title = None

            if coach_mode == "📋 Linked to Application" and linked_application:
                company_name = linked_application.get('company')
                role_title = linked_application.get('job_title') or linked_application.get('title')

            # If no company from linked applications, try to get from user input
            if not company_name:
                if company_input_value:
                    company_name = company_input_value
                elif 'interview_company_input' in st.session_state:
                    company_name = st.session_state.interview_company_input

            company_name = (company_name or "").strip()
            if not company_name:
                st.error("❌ Provide a company name or link an application before generating the pack")
                st.stop()

            st.session_state.umarketu_state['interview_prep'] = {
                'company_name': company_name,
                'role_title': (role_title or role_input_value or "").strip(),
                'company_intel': f"{company_name} - Company intelligence will be generated based on real data...",
                'qa_count': random.randint(25, 35),
                'generated_at': datetime.now().isoformat()
            }
            st.success("✅ Interview pack ready!")
            persist_umarketu_state(user_id)

    # Display interview pack
    if st.session_state.umarketu_state.get('interview_prep'):
        prep = st.session_state.umarketu_state['interview_prep']

        # Interview pack sections
        subtab1, subtab2, subtab3, subtab4, subtab5 = st.tabs([
            "🏢 Company Intel",
            "❓ Q&A Pack",
            "🎭 Behavioral",
            "📅 Day-of Logistics",
            "✉️ Follow-up"
        ])

        with subtab1:
            st.markdown("### 🏢 Company Intelligence")

            company_name = prep.get('company_name', 'Target Company')
            selected_job = st.session_state.umarketu_state.get('selected_job')
            role_title = selected_job.get('title', '') if selected_job else None

            # Generate live company research using AI
            if AI_API_AVAILABLE and user_tier in PREMIUM_TIERS:
                if not ai_service:
                    st.error("⚠️ AI research service is not configured right now. Please try again later.")
                elif st.button("🔍 Generate Live Company Research", key="company_research_btn"):
                    with st.spinner(f"🤖 Researching {company_name} using live AI..."):
                        try:
                            ai_research = ai_service.generate_company_research(company_name, role_title)

                            if ai_research.confidence > 0.5:
                                st.success(f"✅ Live research completed (Provider: {ai_research.provider.title()})")
                                st.caption(f"⚡ Response time: {ai_research.response_time:.2f}s | Tokens used: {ai_research.tokens_used}")

                                # Store research in session state
                                st.session_state.umarketu_state['company_research'] = {
                                    'content': ai_research.content,
                                    'generated_at': datetime.now().isoformat(),
                                    'provider': ai_research.provider
                                }
                                persist_umarketu_state(user_id)
                            else:
                                st.error(f"❌ Research failed: {ai_research.metadata.get('error', 'Unknown error')}")
                        except Exception as e:
                            st.error(f"❌ AI research error: {str(e)}")

            # Display research content
            if st.session_state.umarketu_state.get('company_research'):
                research = st.session_state.umarketu_state['company_research']
                st.markdown("#### 🤖 AI-Generated Company Research")
                st.info(f"Generated via {research.get('provider', 'AI').title()} on {research.get('generated_at', 'Unknown')}")
                st.markdown(research['content'])
            else:
                profile = _get_company_profile(company_name)
                if profile:
                    st.info("📡 Live company intelligence from ai_data corpus")
                    col_meta1, col_meta2 = st.columns(2)
                    with col_meta1:
                        st.metric("Industry", profile.get('industry', 'Unknown'))
                        st.metric("HQ", profile.get('location', 'Unknown'))
                    with col_meta2:
                        st.metric("Dataset Sources", len(profile.get('top_sources', [])))
                        st.metric("Records", profile.get('source_count', '—'))

                    if profile.get('top_sources'):
                        st.markdown("#### Recent References")
                        for source in profile['top_sources'][:5]:
                            st.caption(f"• {source}")

                    if WEB_INTELLIGENCE_AVAILABLE:
                        display_web_intelligence_enhancement("interview_pack", company_name=company_name, job_title=role_title or "Target Role")
                else:
                    st.warning("❌ Company research not yet generated")
                    if user_tier not in PREMIUM_TIERS:
                        st.info("Upgrade to unlock AI-generated research or run a job search to hydrate company data.")

        with subtab2:
            st.markdown("### ❓ Tailored Q&A Pack")
            st.markdown(f"**{prep['qa_count']} questions** prepared based on your profile and the role")

            company_name = prep.get('company_name', 'the company')
            resume_snapshot = extract_resume_snapshot() or st.session_state.get('resume_data', {}) or {}
            fit_analysis = st.session_state.umarketu_state.get('fit_analysis')
            selected_job = st.session_state.umarketu_state.get('selected_job')
            qa_sections: Dict[str, List[str]] = {}

            # Generate dynamic questions using AI APIs
            if AI_API_AVAILABLE and user_tier in PREMIUM_TIERS:
                if not ai_service:
                    st.error("⚠️ Interview AI service is unavailable. Using fit-analysis fallback questions below.")
                else:
                    try:
                        user_profile = st.session_state.get('resume_data', {})
                        job_description = selected_job.get('description', '') if selected_job else ''

                        st.info("🤖 Generating personalized questions using live AI...")

                        ai_response = ai_service.generate_interview_questions(
                            user_profile=user_profile,
                            job_description=job_description,
                            question_count=prep['qa_count'],
                            focus_areas=['technical', 'behavioral', 'company-specific']
                        )

                        if ai_response.confidence > 0.5:
                            st.success(f"✅ Generated {prep['qa_count']} AI-powered questions (Provider: {ai_response.provider.title()})")
                            st.caption(f"⚡ Response time: {ai_response.response_time:.2f}s | Tokens used: {ai_response.tokens_used}")

                            try:
                                questions_data = json.loads(ai_response.content)
                                if isinstance(questions_data, dict):
                                    qa_sections = questions_data
                            except Exception:
                                pass

                            if not qa_sections:
                                qa_sections = {
                                    "AI-Generated Questions": [ai_response.content]
                                }
                        else:
                            st.warning(f"⚠️ AI generation failed: {ai_response.metadata.get('error', 'Unknown error')}")

                    except Exception as e:
                        st.error(f"❌ AI API error: {str(e)}")

            # Deterministic fallback sourced from fit analysis + resume
            if not qa_sections:
                qa_sections = build_interview_question_sections(
                    company_name=company_name,
                    selected_job=selected_job,
                    resume_snapshot=resume_snapshot,
                    fit_analysis=fit_analysis,
                )

            if qa_sections.get('Profile Required'):
                st.warning("⚠️ Upload your resume and run Fit Analysis to unlock personalized sections.")

            if not qa_sections:
                qa_sections = {
                    "General Preparation": [
                        "Tell me about yourself.",
                        "Why are you interested in this role at the company?",
                        "Describe a recent challenge and how you handled it."
                    ]
                }

            for section, questions in qa_sections.items():
                with st.expander(f"📚 {section}", expanded=False):
                    for i, q in enumerate(questions, 1):
                        st.markdown(f"**Q{i}**: {q}")
                        st.markdown("**Suggested Answer Framework**:")
                        st.info("🎯 Touch Point: Highlight your relevant experience...")
                        st.markdown("---")

        with subtab3:
            st.markdown("### 🎭 Behavioral Interview Prep")

            st.markdown("#### 🌟 STAR Method Framework")
            st.code("""
Situation: Set the context
Task: Describe the challenge
Action: Explain what YOU did
Result: Quantify the outcome
""")

            # Generate evidence talking points from real user profile
            user_profile = st.session_state.get('resume_data') or st.session_state.get('user_profile', {})
            if not isinstance(user_profile, dict):
                user_profile = {}

            try:
                if user_profile.get('experience') and len(user_profile['experience']) > 0:
                    st.markdown("#### 💪 Your Evidence Talking Points")
                    st.markdown("*Based on your actual resume and profile:*")

                    evidence_points = []
                    for i, exp in enumerate(user_profile['experience'][:5], 1):
                        if isinstance(exp, dict):
                            role = exp.get('role', 'Professional Role')
                            company = exp.get('company', 'Previous Company')
                            evidence_points.append(f"**{role}**: Experience at {company}")
                        else:
                            evidence_points.append(f"**Experience {i}**: {exp}")

                    if user_profile.get('skills'):
                        evidence_points.append(f"**Technical Skills**: Proficiency in {', '.join(user_profile['skills'][:3])}")

                    if user_profile.get('achievements'):
                        for achievement in user_profile['achievements'][:2]:
                            evidence_points.append(f"**Achievement**: {achievement}")

                    for idx, point in enumerate(evidence_points, 1):
                        st.markdown(f"{idx}. {point}")

                elif user_profile.get('skills') and len(user_profile['skills']) > 0:
                    st.markdown("#### 💪 Your Evidence Talking Points")
                    st.markdown("*Based on your skills profile:*")
                    for i, skill in enumerate(user_profile['skills'][:5], 1):
                        st.markdown(f"{i}. **{skill}**: Demonstrate expertise through specific examples")
                else:
                    st.markdown("#### 💪 Your Evidence Talking Points")
                    st.warning("⚠️ Add your experience and achievements to your profile for personalized talking points!")
                    st.markdown("Complete your profile to see customized evidence points based on:")
                    st.markdown("- Your actual work experience")
                    st.markdown("- Quantifiable achievements")
                    st.markdown("- Technical skills and certifications")
                    st.markdown("- Leadership and project experience")

            except Exception as e:
                st.error("Unable to load your evidence points. Please ensure your profile is complete.")
                st.markdown("#### 💪 Your Evidence Talking Points")
                st.info("Complete your IntelliCV profile to see personalized talking points here.")

            st.markdown("#### 🚫 Common Pitfalls to Avoid")
            st.warning("""
            - ❌ Rambling without structure (use STAR!)
            - ❌ Taking sole credit for team efforts (say "we" then "I")
            - ❌ Negative talk about previous employers
            - ❌ Vague answers without metrics
            """)

        with subtab4:
            st.markdown("### 📅 Day-of-Interview Logistics")

            col1, col2 = st.columns(2)

            with col1:
                st.markdown("#### ⏰ Timeline")
                st.markdown("""
                **T-24 hours**:
                - ✅ Review company intel
                - ✅ Practice top 10 questions
                - ✅ Prepare 3 questions to ask

                **T-2 hours**:
                - ✅ Test video setup (if remote)
                - ✅ Print resume copy
                - ✅ Eat light meal

                **T-15 minutes**:
                - ✅ Deep breathing exercises
                - ✅ Review key talking points
                - ✅ Smile!
                """)

            with col2:
                st.markdown("#### 🎒 Checklist")
                st.checkbox("Resume copies (3x)", value=False)
                st.checkbox("Notepad + pen", value=False)
                st.checkbox("Portfolio/project samples", value=False)
                st.checkbox("Questions to ask (prepared list)", value=False)
                st.checkbox("Contact details (recruiter/interviewer)", value=False)
                st.checkbox("Water bottle", value=False)

                st.markdown("#### 💡 Mindset Tips")
                st.success("""
                - 🧘 You're evaluating them too
                - 💪 Your achievements speak for themselves
                - 🎯 Focus on fit, not perfection
                - 😊 Authenticity > memorization
                """)

        with subtab5:
            st.markdown("### ✉️ Follow-up Email Drafts")

            if not TEMPLATE_ENGINE_AVAILABLE:
                st.warning("Admin templates unavailable. Sync admin portal to unlock curated follow-ups.")
            else:
                company_name = prep.get('company_name') or st.session_state.umarketu_state.get('selected_job', {}).get('company', 'Target Company')
                role_title = prep.get('role_title') or st.session_state.umarketu_state.get('selected_job', {}).get('title', 'Target Role')
                profile_snapshot = st.session_state.get('profile_data') or st.session_state.get('user_profile', {}) or {}
                resume_snapshot = extract_resume_snapshot() or st.session_state.get('resume_data', {}) or {}

                st.caption("Powered by admin follow-up + acceptance template library")

                override_col1, override_col2 = st.columns(2)
                with override_col1:
                    interviewer_name = st.text_input("Interviewer / Hiring Manager", value=profile_snapshot.get('interviewer_name', 'Hiring Manager'))
                    highlight_takeaway = st.text_input("Conversation Highlight", value="the roadmap priorities we discussed")
                    interview_time = st.text_input("Interview Time", value=datetime.now().strftime("%H:%M"))
                with override_col2:
                    project_reference = st.text_input("Team / Project", value=st.session_state.umarketu_state.get('selected_job', {}).get('department', 'the team'))
                    challenge_reference = st.text_input("Challenge Discussed", value='the initiatives you outlined')
                    contact_follow_up = st.text_input("Recruiter / CC", value=profile_snapshot.get('recruiter_name', 'Recruiter'))

                context_overrides = {
                    'interviewer_name': interviewer_name,
                    'hiring_manager_name': interviewer_name,
                    'specific_element_you_liked': highlight_takeaway,
                    'team_or_project': project_reference,
                    'challenge_or_goal': challenge_reference,
                    'interview_time': interview_time,
                    'contact_name': contact_follow_up,
                }

                placeholders = build_followup_placeholders(
                    company_name=company_name,
                    role_title=role_title,
                    profile_snapshot=profile_snapshot,
                    resume_snapshot=resume_snapshot,
                    context_overrides=context_overrides,
                )

                follow_templates = list_templates(TemplateCategory.FOLLOW_UP)
                accept_templates = list_templates(TemplateCategory.INTERVIEW_ACCEPT)

                def build_template_options(paths: List[Path]) -> Dict[str, Path]:
                    options: Dict[str, Path] = {}
                    for path in paths:
                        label = path.stem.replace('_', ' ').title()
                        options[label] = path
                    return options

                follow_options = build_template_options(follow_templates)
                accept_options = build_template_options(accept_templates)

                col_follow, col_accept = st.columns(2)

                with col_follow:
                    st.markdown("#### 📧 Interview Follow-up")
                    follow_choice = st.selectbox(
                        "Template",
                        list(follow_options.keys()) or ["No templates available"],
                        key="follow_template_select"
                    )
                    follow_output = ""
                    if follow_choice in follow_options:
                        follow_raw = load_template_text(follow_options[follow_choice])
                        follow_output = render_template_with_placeholders(follow_raw, placeholders)
                        st.text_area("Rendered Email", value=follow_output, height=260)
                        if st.button("📋 Copy Follow-up", key="copy_followup"):
                            st.success("✅ Follow-up ready to paste")
                    else:
                        st.info("Upload templates via admin portal to enable follow-ups.")

                with col_accept:
                    st.markdown("#### ✅ Interview Acceptance / Scheduling")
                    accept_choice = st.selectbox(
                        "Template",
                        list(accept_options.keys()) or ["No templates available"],
                        key="accept_template_select"
                    )
                    accept_output = ""
                    if accept_choice in accept_options:
                        accept_raw = load_template_text(accept_options[accept_choice])
                        accept_output = render_template_with_placeholders(accept_raw, placeholders)
                        st.text_area("Rendered Email", value=accept_output, height=260)
                        if st.button("📋 Copy Acceptance", key="copy_accept"):
                            st.success("✅ Acceptance email copied")
                    else:
                        st.info("No acceptance templates synced from admin portal.")

                if follow_choice in follow_options and st.button("💾 Log Follow-up Draft", key="log_followup"):
                    draft_entry = {
                        'company': company_name,
                        'job_title': role_title,
                        'template_used': follow_choice,
                        'generated_at': datetime.now().isoformat(),
                        'body': follow_output,
                        'type': 'follow_up'
                    }
                    st.session_state.umarketu_state.setdefault('saved_follow_ups', []).append(draft_entry)
                    persist_umarketu_state(user_id)
                    st.success("📨 Follow-up logged to your prep notes")

# ===========================
# TAB 6: PARTNER MODE
# ===========================
with tab6:
    st.header("👥 Partner Mode - Dual Career Optimizer")
    st.markdown("**US9**: Add partner profile and run dual-career search with travel constraints")

    # Tier gate for partner mode
    if user_tier not in ['annual_pro', 'enterprise_pro']:
        st.warning("🔒 **Partner Mode** is available for Annual Pro and Enterprise Pro tiers")
        if st.button("⬆️ Upgrade to Annual Pro"):
            st.switch_page("pages/06_Pricing.py")
        st.stop()

    # Partner profile setup
    st.markdown("### 👤 Partner Profile")

    partner_mode_state = st.session_state.umarketu_state.setdefault('partner_mode', {})
    p2_resume_snapshot = partner_mode_state.get('p2_resume_snapshot')
    user_resume_snapshot = resume_snapshot

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("#### Partner 1 (You)")
        full_name_default = (
            profile_data.get('full_name')
            or " ".join(filter(None, [profile_data.get('first_name'), profile_data.get('last_name')])).strip()
            or st.session_state.get('user_email', 'User 1')
        )
        p1_name = st.text_input("Name", value=full_name_default, key="p1_name")

        if user_resume_snapshot:
            st.success("Using your uploaded resume from Resume Analysis")
            meta = user_resume_snapshot.get('metadata', {})
            if meta.get('file_name'):
                st.caption(f"Source file: {meta['file_name']}")
            top_skills = extract_resume_skills(user_resume_snapshot)[:5]
            if top_skills:
                st.caption("Top skills: " + ", ".join(top_skills))
        else:
            st.warning("No resume on file. Upload via Resume Analysis (page 09) to unlock tailored matching.")
            if st.button("📤 Open Resume Upload", key="partner_mode_resume_nav"):
                st.switch_page("pages/09_Resume_Upload_Analysis.py")

        p1_roles_default = derive_target_roles_from_snapshot(user_resume_snapshot) or "ML Engineer, Data Scientist"
        p1_roles = st.text_input("Target Roles", value=p1_roles_default, key="p1_roles")

        metadata = user_resume_snapshot.get('metadata', {}) if user_resume_snapshot else {}
        salary_seed = metadata.get('target_salary')
        salary_default = 60000
        if isinstance(salary_seed, (int, float)):
            salary_default = int(salary_seed)
        elif isinstance(salary_seed, str):
            digits = re.findall(r"\d+", salary_seed.replace(',', ''))
            if digits:
                salary_default = int(digits[0])
        salary_default = min(200000, max(50000, salary_default))
        p1_min_salary = st.number_input("Min Salary (£)", 50000, 200000, salary_default, key="p1_salary")

    with col2:
        st.markdown("#### Partner 2")
        p2_name = st.text_input("Name", value=partner_mode_state.get('p2_name', 'Partner'), key="p2_name")

        uploaded_partner_resume = st.file_uploader(
            "📎 Partner Resume (drag & drop PDF/DOCX/TXT)",
            type=['pdf', 'docx', 'txt'],
            accept_multiple_files=False,
            key="p2_resume",
            help="We parse the resume instantly to personalize partner opportunities."
        )

        if uploaded_partner_resume:
            resume_changed = (
                not p2_resume_snapshot
                or uploaded_partner_resume.name != partner_mode_state.get('p2_resume_filename')
            )
            if resume_changed:
                parsed_partner_resume = parse_partner_resume_upload(uploaded_partner_resume)
                if parsed_partner_resume:
                    partner_mode_state['p2_resume_snapshot'] = parsed_partner_resume
                    partner_mode_state['p2_resume_filename'] = uploaded_partner_resume.name
                    partner_mode_state['p2_resume_uploaded_at'] = datetime.now().isoformat()
                    p2_resume_snapshot = parsed_partner_resume
                    derived_partner_roles = derive_target_roles_from_snapshot(parsed_partner_resume) or "UX Designer, Product Manager"
                    st.session_state['p2_roles'] = derived_partner_roles
                    persist_umarketu_state(user_id)
                    st.success(f"✅ Parsed {uploaded_partner_resume.name}")

        if p2_resume_snapshot:
            st.info(f"Partner resume on file: {partner_mode_state.get('p2_resume_filename', 'Uploaded resume')}")
            partner_skills = extract_resume_skills(p2_resume_snapshot)[:5]
            if partner_skills:
                st.caption("Top skills: " + ", ".join(partner_skills))
        else:
            st.info("Drag & drop a partner resume to unlock dual-career intelligence.")

        partner_roles_default = (
            st.session_state.get('p2_roles')
            or derive_target_roles_from_snapshot(p2_resume_snapshot)
            or "UX Designer, Product Manager"
        )
        p2_roles = st.text_input("Target Roles", value=partner_roles_default, key="p2_roles")
        p2_min_salary = st.number_input("Min Salary (£)", 50000, 200000, 55000, key="p2_salary")

    # Geographic constraints
    st.markdown("### 🗺️ Geographic & Lifestyle Constraints")

    col1, col2, col3 = st.columns(3)

    with col1:
        max_commute_p1 = st.slider("P1 Max Commute (km)", 0, 100, 30, 5)
        max_commute_p2 = st.slider("P2 Max Commute (km)", 0, 100, 25, 5)

    with col2:
        remote_flex_p1 = st.select_slider("P1 Remote Flexibility", ["On-site only", "Hybrid", "Fully Remote"], value="Hybrid")
        remote_flex_p2 = st.select_slider("P2 Remote Flexibility", ["On-site only", "Hybrid", "Fully Remote"], value="Hybrid")

    with col3:
        relocation_budget = 0
        relocation_willing = st.checkbox("Open to Relocation", value=True)
        if relocation_willing:
            relocation_budget = st.number_input("Relocation Budget (£)", 0, 50000, 10000, 1000)

    home_base_location = (
        profile_data.get('location')
        or user_resume_snapshot.get('metadata', {}).get('location')
        or analysis_results.get('location')
        or partner_mode_state.get('home_base')
        or ''
    )
    if home_base_location and partner_mode_state.get('home_base') != home_base_location:
        partner_mode_state['home_base'] = home_base_location

    dual_results = partner_mode_state.get('dual_results', []) or []
    dual_context = partner_mode_state.get('dual_context', {}) or {}

    # Run dual-career optimizer
    if st.button("🔍 Find Optimal Cities & Jobs", type="primary", use_container_width=True):
        with st.spinner("🧠 Optimizing dual-career opportunities..."):
            p1_profile_payload = {
                'name': p1_name,
                'skills': extract_resume_skills(user_resume_snapshot),
                'experience_years': get_resume_experience_years(user_resume_snapshot) if user_resume_snapshot else 0.0,
                'role_keywords': _split_role_keywords(p1_roles),
                'remote_flex': remote_flex_p1,
                'min_salary': int(p1_min_salary),
                'max_commute': max_commute_p1,
                'home_base': home_base_location,
                'min_fit_score': 55,
            }
            p2_profile_payload = {
                'name': p2_name,
                'skills': extract_resume_skills(p2_resume_snapshot) if p2_resume_snapshot else [],
                'experience_years': get_resume_experience_years(p2_resume_snapshot) if p2_resume_snapshot else 0.0,
                'role_keywords': _split_role_keywords(p2_roles),
                'remote_flex': remote_flex_p2,
                'min_salary': int(p2_min_salary),
                'max_commute': max_commute_p2,
                'home_base': home_base_location,
                'min_fit_score': 45,
            }

            recommendations = build_dual_career_recommendations(
                p1_profile_payload,
                p2_profile_payload,
                relocation_allowed=relocation_willing,
                relocation_budget=int(relocation_budget or 0),
            )
            dual_results = recommendations.get('cities', [])
            dual_context = {
                'job_source': recommendations.get('job_source'),
                'generated_at': datetime.now().isoformat(),
                'p1_profile': {'name': p1_name, 'roles': p1_roles},
                'p2_profile': {'name': p2_name, 'roles': p2_roles},
                'avg_commute_limit': (max_commute_p1 + max_commute_p2) / 2,
                'p1_total_jobs': recommendations.get('p1_total_jobs', 0),
                'p2_total_jobs': recommendations.get('p2_total_jobs', 0),
                'relocation_willing': relocation_willing,
            }
            partner_mode_state['dual_results'] = dual_results
            partner_mode_state['dual_context'] = dual_context
            persist_umarketu_state(user_id)

            if dual_results:
                st.success(f"✅ Found {len(dual_results)} cities with overlapping opportunities.")
            else:
                if recommendations.get('p1_total_jobs') == 0:
                    st.warning("No live roles matched Partner 1's criteria. Try widening skills or titles and rerun.")
                elif recommendations.get('p2_total_jobs') == 0:
                    st.warning("No live roles matched Partner 2's criteria. Upload a resume or broaden their target roles.")
                else:
                    st.warning("We couldn't find cities where both partners have roles. Expand remote flexibility or allow relocation.")

    if dual_results:
        st.markdown("### 🎯 Dual-Career Opportunity Matrix")
        table_rows = []
        for row in dual_results:
            table_rows.append({
                'City': row['city'],
                'P1 Jobs': row['p1_job_count'],
                'P2 Jobs': row['p2_job_count'],
                'Combined Score': row['combined_score'],
                'Remote Coverage': f"{int(row['remote_share'] * 100)}%",
                'Median Salary': f"£{row['median_salary']:,.0f}" if row['median_salary'] else '—',
                'Budget Alignment': row['budget_alignment'],
                'Commute Fit': f"{int(row['commute_fit'] * 100)}%",
            })
        df_dual = pd.DataFrame(table_rows)
        st.dataframe(df_dual, use_container_width=True)

        source_label = "Shared IO Layer" if dual_context.get('job_source') == 'io_layer' else "Last job search snapshot"
        generated_at = dual_context.get('generated_at')
        st.caption(f"Source: {source_label} • Generated {generated_at or 'just now'}")

        st.markdown("### 🎯 Dual-Career Opportunity Radar")
        fig = go.Figure()
        max_p1 = max((row['p1_job_count'] for row in dual_results), default=1)
        max_p2 = max((row['p2_job_count'] for row in dual_results), default=1)
        for row in dual_results[:5]:
            fig.add_trace(go.Scatterpolar(
                r=[
                    (row['p1_job_count'] / max_p1) * 100 if max_p1 else 0,
                    (row['p2_job_count'] / max_p2) * 100 if max_p2 else 0,
                    row['combined_score'],
                    row['remote_share'] * 100,
                    row['commute_fit'] * 100,
                ],
                theta=['P1 Opportunities', 'P2 Opportunities', 'Overall Fit', 'Remote Coverage', 'Commute Fit'],
                fill='toself',
                name=row['city']
            ))

        fig.update_layout(
            polar=dict(radialaxis=dict(visible=True, range=[0, 100])),
            showlegend=True,
            height=500
        )

        st.plotly_chart(fig, use_container_width=True)

        city_labels = [row['city'] for row in dual_results]
        selected_city = st.selectbox("🏙️ View Details for City", city_labels)
        if selected_city:
            city_data = next(row for row in dual_results if row['city'] == selected_city)
            st.markdown(f"### 📍 {selected_city} - Detailed Breakdown")

            metrics_col1, metrics_col2, metrics_col3 = st.columns(3)
            metrics_col1.metric("P1 Matches", city_data['p1_job_count'])
            metrics_col2.metric("P2 Matches", city_data['p2_job_count'])
            metrics_col3.metric("Combined Score", city_data['combined_score'])

            detail_col1, detail_col2 = st.columns(2)

            def _render_partner_jobs(container, jobs: List[Dict[str, Any]], partner_label: str) -> None:
                container.markdown(f"#### {partner_label} Opportunities")
                if not jobs:
                    container.info("No matches for this partner in this city.")
                    return
                container.markdown("**Top Matches:**")
                for idx, job in enumerate(jobs[:3], 1):
                    salary_text = job.get('salary') or 'Competitive'
                    container.markdown(
                        f"{idx}. **{job['title']}** @ {job['company']}  \n"
                        f"{salary_text} • {job['remote']} | Quick Fit {job.get('quick_fit', 0)}%"
                    )
                    if job.get('url'):
                        container.caption(f"[Open role]({job['url']})")

            _render_partner_jobs(detail_col1, city_data['p1_jobs'], f"Partner 1 ({p1_name})")
            _render_partner_jobs(detail_col2, city_data['p2_jobs'], f"Partner 2 ({p2_name})")

            st.markdown("#### 🚗 Commute & Logistics")
            salary_span = "—"
            if city_data.get('salary_low') and city_data.get('salary_high'):
                salary_span = f"£{city_data['salary_low']:,.0f} - £{city_data['salary_high']:,.0f}"
            elif city_data.get('median_salary'):
                salary_span = f"£{city_data['median_salary']:,.0f}"
            st.info(
                f"- Remote coverage: {int(city_data['remote_share'] * 100)}% of paired roles allow hybrid/remote options\n"
                f"- Estimated commute load: ~{city_data['estimated_commute_minutes']} min average based on your limits\n"
                f"- Budget alignment: {city_data['budget_alignment']} (salary window {salary_span})"
            )

    else:
        st.info("Run the optimizer after uploading both resumes to see overlapping cities with live data.")

# Footer with next actions
st.markdown("---")
st.markdown("### 🚀 Quick Actions")

col1, col2, col3, col4 = st.columns(4)

with col1:
    if st.button("💾 Save Progress", use_container_width=True):
        st.success("✅ Progress saved!")

with col2:
    if st.button("📊 View Analytics", use_container_width=True):
        st.info("📈 Opening analytics dashboard...")

with col3:
    if st.button("⚙️ Settings", use_container_width=True):
        st.info("🔧 Opening settings...")

with col4:
    if st.button("❓ Help & Tutorials", use_container_width=True):
        st.info("📚 Opening help center...")

# Session state debug (for development)
if st.checkbox("🔧 Debug: Show Session State", value=False):
    st.json(st.session_state.umarketu_state)
