"""
🎓 Coaching Hub - Your Comprehensive Career Coaching Center
===========================================================
Unified coaching platform with AI-powered specialists:
- 🎤 Interview Coach: Interview preparation, Q&A practice, performance feedback
- 📊 Career Coach: Career planning, skill development, trajectory optimization
- 🤝 Mentorship Coach: Mentor matching, session management, growth tracking

Each coach includes dedicated AI chatbot for personalized guidance.

Token Cost: 15 tokens | Premium Feature
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path
from statistics import mean
from typing import Any, Dict, List, Optional, Tuple, Sequence
from uuid import uuid4
import json
import sys

# Setup paths
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))

# Import portal bridge for cross-portal communication
try:
    from shared_backend.services.portal_bridge import ChatService
    chat_service = ChatService()
    PORTAL_BRIDGE_AVAILABLE = True
except ImportError as e:
    PORTAL_BRIDGE_AVAILABLE = False
    chat_service = None

try:
    from job_title_backend_integration import JobTitleBackend
    job_cloud_bridge = JobTitleBackend(user_id=st.session_state.get('user_id'))
    JOB_CLOUD_AVAILABLE = True
except Exception:
    job_cloud_bridge = None
    JOB_CLOUD_AVAILABLE = False

try:
    from services.user_data_service import UserDataService
    user_data_service = UserDataService()
    USER_DATA_SERVICE_AVAILABLE = True
except Exception:
    user_data_service = None
    USER_DATA_SERVICE_AVAILABLE = False

try:
    from shared.interview_question_library import (
        INTERVIEW_QUESTION_LIBRARY,
        filter_interview_questions,
    )
    QUESTION_LIBRARY_AVAILABLE = True
except Exception:
    INTERVIEW_QUESTION_LIBRARY = []
    QUESTION_LIBRARY_AVAILABLE = False

    def filter_interview_questions(*_args, **_kwargs):  # type: ignore
        return []


def get_resume_snapshot() -> Dict[str, Any]:
    """Return the latest resume snapshot or derived analysis data."""
    snapshot = st.session_state.get('resume_data')
    if snapshot and isinstance(snapshot, dict):
        return snapshot

    analysis = st.session_state.get('analysis_results', {})
    if analysis:
        return {
            'metadata': {
                'name': analysis.get('name'),
                'quality_score': analysis.get('basic_score'),
                'total_years_experience': analysis.get('experience_years')
            },
            'skills': analysis.get('tech_keywords', [])
        }
    return {}


def extract_resume_skills(snapshot: Optional[Dict[str, Any]]) -> List[str]:
    if not snapshot:
        return []
    skills = snapshot.get('skills')
    if isinstance(skills, list):
        return [skill for skill in skills if isinstance(skill, str)]
    metadata_skills = snapshot.get('metadata', {}).get('skills')
    if isinstance(metadata_skills, list):
        return [skill for skill in metadata_skills if isinstance(skill, str)]
    return []


def get_experience_entries(snapshot: Dict[str, Any]) -> List[Dict[str, Any]]:
    experience = snapshot.get('experience') or snapshot.get('work_experience') or []
    if isinstance(experience, list):
        return [entry for entry in experience if isinstance(entry, dict)]
    return []


def derive_current_role(snapshot: Dict[str, Any], analysis: Dict[str, Any], profile: Dict[str, Any]) -> Optional[str]:
    experience_entries = get_experience_entries(snapshot)
    if experience_entries:
        return experience_entries[0].get('title') or experience_entries[0].get('role')
    return (
        snapshot.get('metadata', {}).get('current_role')
        or analysis.get('current_role')
        or profile.get('current_role')
    )


def get_total_experience_years(snapshot: Dict[str, Any], analysis: Dict[str, Any]) -> Optional[float]:
    years = snapshot.get('metadata', {}).get('total_years_experience')
    if years:
        return years
    return analysis.get('experience_years')


def infer_role_type(selected_job: Optional[Dict[str, Any]], resume_snapshot: Dict[str, Any]) -> str:
    text_sources: List[str] = []
    if isinstance(selected_job, dict):
        text_sources.extend([
            str(selected_job.get('title', '')),
            str(selected_job.get('department', '')),
            str(selected_job.get('team', '')),
        ])
    metadata = resume_snapshot.get('metadata', {}) if isinstance(resume_snapshot, dict) else {}
    text_sources.extend([
        str(metadata.get('current_role', '')),
        str(metadata.get('headline', '')),
        str(resume_snapshot.get('headline', '')),
    ])
    text_blob = " ".join(text_sources).lower()
    role_mappings = [
        (('product', 'pm', 'roadmap'), 'product'),
        (('ux', 'designer'), 'product'),
        (('data', 'analytics'), 'data'),
        (('machine learning', 'ml', 'ai'), 'ml'),
        (('software', 'engineer', 'developer'), 'engineering'),
    ]
    for keywords, role in role_mappings:
        if any(keyword in text_blob for keyword in keywords):
            return role
    return 'any'


def infer_seniority(
    selected_job: Optional[Dict[str, Any]],
    analysis: Dict[str, Any],
    resume_snapshot: Dict[str, Any],
) -> str:
    title_candidates: List[str] = []
    if isinstance(selected_job, dict):
        title_candidates.append(str(selected_job.get('title', '')))
    metadata = resume_snapshot.get('metadata', {}) if isinstance(resume_snapshot, dict) else {}
    title_candidates.extend([
        str(metadata.get('current_role', '')),
        str(analysis.get('current_role', '')),
    ])
    title_text = " ".join(title_candidates).lower()
    if any(token in title_text for token in ('chief', 'head', 'vp', 'vice president', 'director', 'cxo')):
        return 'exec'
    if any(token in title_text for token in ('principal', 'staff', 'lead', 'senior')):
        return 'senior'
    if any(token in title_text for token in ('intern', 'junior', 'graduate', 'associate')):
        return 'junior'

    years = metadata.get('total_years_experience') or analysis.get('experience_years')
    if isinstance(years, (int, float)):
        if years >= 10:
            return 'senior'
        if years <= 3:
            return 'junior'
    return 'mid'


def safe_parse_date(value: Any) -> Optional[datetime]:
    if isinstance(value, datetime):
        return value
    if hasattr(value, 'to_pydatetime'):
        return value.to_pydatetime()
    if isinstance(value, str):
        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%Y/%m/%d"):
            try:
                return datetime.strptime(value, fmt)
            except ValueError:
                continue
    return None


def build_upcoming_interviews(manual_sessions: List[Dict[str, Any]], applications: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    today = datetime.now().date()
    rows: List[Dict[str, Any]] = []

    for session in manual_sessions:
        session_date = safe_parse_date(session.get('date'))
        if session_date and session_date.date() >= today:
            rows.append({
                'Company': session.get('company', 'Unknown'),
                'Position': session.get('position', 'Role'),
                'Date': session_date.strftime("%Y-%m-%d"),
                'Type': session.get('type', 'Interview'),
                'Status': session.get('status', '🟡 Preparing')
            })

    for application in applications:
        timeline = application.get('timeline', [])
        for event in timeline:
            label = str(event.get('event', '')).lower()
            if 'interview' not in label:
                continue
            event_date = safe_parse_date(event.get('date'))
            if not event_date or event_date.date() < today:
                continue
            rows.append({
                'Company': application.get('company', 'Company'),
                'Position': application.get('job_title', application.get('title', 'Role')),
                'Date': event_date.strftime("%Y-%m-%d"),
                'Type': event.get('event', 'Interview'),
                'Status': '🟢 Scheduled' if 'scheduled' in label else '🟡 Preparing'
            })

    # Deduplicate by company/date/type
    deduped = {}
    for row in rows:
        key = (row['Company'], row['Position'], row['Date'], row['Type'])
        deduped[key] = row

    return sorted(deduped.values(), key=lambda r: r['Date'])


def compute_peer_skill_coverage(target_skills: List[str], user_id: str) -> Dict[str, float]:
    if not (USER_DATA_SERVICE_AVAILABLE and user_data_service and target_skills):
        return {}
    try:
        peers = user_data_service.get_peer_candidates(user_id=user_id, limit=25)
    except Exception:
        return {}

    if not peers:
        return {}

    totals = Counter()
    for peer in peers:
        peer_skills = peer.get('profile', {}).get('skills', []) or []
        normalized = {skill.lower() for skill in peer_skills if isinstance(skill, str)}
        for skill in target_skills:
            if skill.lower() in normalized:
                totals[skill.lower()] += 1

    peer_count = len(peers)
    return {skill.lower(): (totals.get(skill.lower(), 0) / peer_count) * 100 for skill in target_skills}


def compute_leadership_index(experience_entries: List[Dict[str, Any]]) -> float:
    if not experience_entries:
        return 0.0
    leadership_keywords = ("lead", "manage", "director", "head", "mentor")
    matches = 0
    for entry in experience_entries:
        text = " ".join(str(entry.get(field, '')) for field in ('title', 'summary', 'description')).lower()
        if any(keyword in text for keyword in leadership_keywords):
            matches += 1
    return min(1.0, matches / len(experience_entries))


def compute_visibility_index(snapshot: Dict[str, Any]) -> float:
    achievements = snapshot.get('achievements') or snapshot.get('awards') or snapshot.get('publications') or []
    if not isinstance(achievements, list) or not achievements:
        return 0.0
    return min(1.0, len(achievements) / 5)


def compute_strategy_index(snapshot: Dict[str, Any]) -> float:
    projects = snapshot.get('projects') or []
    if not isinstance(projects, list) or not projects:
        return 0.0
    strategic_projects = [project for project in projects if isinstance(project, dict) and project.get('impact')]
    return min(1.0, len(strategic_projects) / max(len(projects), 1))


LEARNING_RESOURCE_LIBRARY = [
    (("aws", "cloud", "gcp", "azure"), {
        'course': "AWS Solutions Architect Accelerator (A Cloud Guru, 20h)",
        'certification': "AWS Solutions Architect Associate",
        'book': "Cloud Strategy - Gregor Hohpe"
    }),
    (("lead", "manager", "mentor"), {
        'course': "Engineering Leadership Foundations (LeadDev, 8h)",
        'certification': "Situational Leadership Credential",
        'book': "The Staff Engineer's Path - Tanya Reilly"
    }),
    (("system", "architecture", "design"), {
        'course': "System Design Interview Masterclass (Educative, 25h)",
        'certification': "GCP Professional Cloud Architect",
        'book': "Designing Data-Intensive Applications - Martin Kleppmann"
    }),
    (("ml", "machine", "ai"), {
        'course': "Machine Learning Engineering for Production (DeepLearning.AI, 40h)",
        'certification': "TensorFlow Developer Certificate",
        'book': "Building Machine Learning Powered Applications - Emmanuel Ameisen"
    }),
    (("data", "analytics", "sql"), {
        'course': "Advanced SQL & Data Modeling (Mode, 12h)",
        'certification': "Databricks Data Engineer Associate",
        'book': "Storytelling with Data - Cole Nussbaumer Knaflic"
    }),
    (("communication", "story", "presentation"), {
        'course': "Executive Communication Lab (Reforge, 6h)",
        'certification': "Toastmasters Competent Communicator",
        'book': "Resonate - Nancy Duarte"
    })
]


def estimate_skill_strength(skill: str, resume_skills: List[str], experience_entries: List[Dict[str, Any]]) -> float:
    """Approximate a score based on documented experience signals."""
    if not skill:
        return 0.0
    skill_lower = skill.lower()
    hits = 0
    samples = 0

    for entry in experience_entries:
        text = " ".join(str(entry.get(field, '')) for field in ('title', 'summary', 'description')).lower()
        if text.strip():
            samples += 1
            if skill_lower in text:
                hits += 1

    if resume_skills:
        samples += 1
        if any(skill_lower == s.lower() for s in resume_skills):
            hits += 1

    if samples == 0:
        return 0.0

    return round(40 + (hits / samples) * 60, 1)


def recommend_learning_resource(skill: str) -> Dict[str, str]:
    skill_lower = (skill or "").lower()
    for keywords, resources in LEARNING_RESOURCE_LIBRARY:
        if any(keyword in skill_lower for keyword in keywords):
            return resources
    safe_skill = skill or "Skill"
    return {
        'course': f"{safe_skill} Mastery Sprint (self-directed, 10h)",
        'certification': f"{safe_skill.title()} Practitioner Credential",
        'book': f"Collect three case studies that showcase measurable {safe_skill} impact"
    }


def fetch_peer_mentor_suggestions(
    user_id: str,
    focus_skill: Optional[str],
    sector: Optional[str],
    limit: int = 5
) -> List[Dict[str, Any]]:
    """Return mentor-style suggestions derived from live peer data."""
    if not (USER_DATA_SERVICE_AVAILABLE and user_data_service):
        return []

    try:
        bundle = user_data_service.get_user_data(user_id=user_id)
    except Exception:
        return []

    peers = bundle.get('peers') or []
    suggestions: List[Dict[str, Any]] = []
    focus_lower = (focus_skill or "").lower()
    sector_lower = (sector or "").lower()

    for peer in peers:
        profile = peer.get('profile') or peer
        skills = profile.get('skills') or peer.get('skills') or []
        industries = profile.get('industries') or peer.get('industries') or []
        experiences = profile.get('experience') or peer.get('experience') or []
        experience_years = profile.get('experience_years') or peer.get('experience_years')

        if focus_lower and not any((skill or "").lower() == focus_lower for skill in skills):
            continue

        if sector_lower:
            normalized_industries = {
                (industry or "").lower() for industry in industries if isinstance(industry, str)
            }
            if normalized_industries and sector_lower not in normalized_industries:
                continue

        primary_company = ""
        if isinstance(experiences, list) and experiences:
            primary_company = experiences[0].get('company', '')

        suggestions.append({
            'name': profile.get('name') or peer.get('name') or "Mentor",
            'role': profile.get('title') or profile.get('current_role') or peer.get('title'),
            'company': primary_company or profile.get('company') or peer.get('company') or "—",
            'experience_years': experience_years,
            'skills': skills,
            'industry': industries[0] if industries else None
        })

        if len(suggestions) >= limit:
            break

    return suggestions


def _dedupe_preserve_case(items: Sequence[Any]) -> List[str]:
    """Return items once while keeping display casing."""
    ordered: List[str] = []
    seen: set[str] = set()
    for item in items:
        if not isinstance(item, str):
            continue
        key = item.strip().lower()
        if not key or key in seen:
            continue
        seen.add(key)
        ordered.append(item.strip())
    return ordered


def _derive_resume_text(snapshot: Dict[str, Any]) -> str:
    """Best-effort resume text for job cloud context."""
    candidates = [
        st.session_state.get('uploaded_resume_content'),
        snapshot.get('raw_text'),
        snapshot.get('content'),
        snapshot.get('full_text'),
    ]
    for candidate in candidates:
        if isinstance(candidate, str) and candidate.strip():
            return candidate.strip()

    fragments: List[str] = []
    experiences = get_experience_entries(snapshot)
    for entry in experiences[:3]:
        for field in ('title', 'summary', 'description'):
            value = entry.get(field)
            if isinstance(value, str) and value.strip():
                fragments.append(value.strip())

    summary = snapshot.get('metadata', {}).get('summary')
    if isinstance(summary, str) and summary.strip():
        fragments.append(summary.strip())
    else:
        skill_sample = ", ".join(extract_resume_skills(snapshot)[:10])
        if skill_sample:
            fragments.append(skill_sample)

    return "\n".join(fragments).strip()


def _ensure_job_cloud_tokens() -> None:
    """Guarantee a starter token balance for job cloud calls."""
    wallet = st.session_state.get('token_wallet')
    if not isinstance(wallet, dict):
        wallet = {}

    if wallet.get('job_cloud', 0) <= 0:
        wallet['job_cloud'] = 35

    st.session_state['token_wallet'] = wallet
    st.session_state.setdefault('user_tokens', 40)


def _normalize_relationships(payload: Any) -> Dict[str, List[str]]:
    """Normalize backend relationship payloads for display."""
    normalized = {
        'similar_titles': [],
        'lateral_moves': [],
        'advancement_roles': []
    }

    if isinstance(payload, dict):
        rel_block = payload.get('relationships') if 'relationships' in payload else payload
        if isinstance(rel_block, dict):
            normalized['similar_titles'] = _dedupe_preserve_case(rel_block.get('similar_titles', []))
            normalized['lateral_moves'] = _dedupe_preserve_case(rel_block.get('lateral_moves', []))
            normalized['advancement_roles'] = _dedupe_preserve_case(rel_block.get('advancement_roles', []))
        elif payload.get('relationship_type'):
            titles = payload.get('titles') or payload.get('roles') or []
            normalized['similar_titles'] = _dedupe_preserve_case(titles)

    elif isinstance(payload, list):
        similar: List[str] = []
        lateral: List[str] = []
        advancement: List[str] = []
        for entry in payload:
            if not isinstance(entry, dict):
                continue
            relation_type = (entry.get('relationship_type') or '').lower()
            titles = entry.get('titles') or entry.get('roles') or []
            if 'similar' in relation_type:
                similar.extend(titles)
            elif 'lateral' in relation_type:
                lateral.extend(titles)
            elif 'progression' in relation_type or 'advancement' in relation_type:
                advancement.extend(titles)
        normalized['similar_titles'] = _dedupe_preserve_case(similar)
        normalized['lateral_moves'] = _dedupe_preserve_case(lateral)
        normalized['advancement_roles'] = _dedupe_preserve_case(advancement)

    return normalized


def _refresh_job_cloud_snapshot(
    target_title: str,
    resume_text: str,
    resume_skills: List[str]
) -> Optional[Dict[str, Any]]:
    """Call the admin job cloud service and shape the payload for UI."""
    if not (JOB_CLOUD_AVAILABLE and job_cloud_bridge and target_title):
        return None

    _ensure_job_cloud_tokens()

    try:
        context = (resume_text or ' ')[:1400]
        analysis = job_cloud_bridge.analyze_job_title(target_title, context=context) or {}
        relationships_raw = job_cloud_bridge.get_title_relationships(base_title=target_title) or {}
        market_raw = job_cloud_bridge.get_market_intelligence(job_category=target_title) or {}
    except Exception:
        return None

    relationships = _normalize_relationships(relationships_raw)
    job_category = (
        analysis.get('ai_analysis', {}).get('predicted_category')
        or analysis.get('ai_category')
        or market_raw.get('job_category')
        or target_title
    )
    confidence = (
        analysis.get('ai_analysis', {}).get('confidence_score')
        or analysis.get('confidence_score')
        or market_raw.get('confidence_score')
        or 0.62
    )

    peer_skill_pool: List[str] = []
    market_analysis = analysis.get('market_intelligence', {})
    peer_skill_pool.extend(market_analysis.get('skills_in_demand', []))
    peer_skill_pool.extend(analysis.get('ai_recommendations', {}).get('skill_gaps', []))

    market_pool = market_raw.get('market_analysis', {})
    peer_skill_pool.extend(market_pool.get('skills_in_demand', []))
    skills_demand = market_raw.get('skills_demand', {})
    if isinstance(skills_demand, dict):
        for bucket in ('trending_up', 'emerging'):
            peer_skill_pool.extend(skills_demand.get(bucket, []))

    peer_skill_pool = _dedupe_preserve_case(peer_skill_pool)
    if not peer_skill_pool and resume_skills:
        peer_skill_pool = resume_skills[:5]

    resume_lookup = {skill.lower(): skill for skill in resume_skills}
    touchpoints: List[Dict[str, str]] = []
    touchnots: List[Dict[str, str]] = []

    peer_anchor = relationships['similar_titles'][0] if relationships['similar_titles'] else target_title
    for skill in peer_skill_pool:
        lower = skill.lower()
        if lower in resume_lookup:
            touchpoints.append({
                'skill': resume_lookup[lower],
                'reason': f"Documented already – anchor it to measurable {job_category} wins."
            })
        else:
            touchnots.append({
                'skill': skill,
                'reason': f"Peers tagged as {peer_anchor} surface this in interview answers."
            })

    peer_skill_lower = {skill.lower() for skill in peer_skill_pool}
    under_bushel: List[Dict[str, str]] = []
    for skill in resume_skills:
        if skill.lower() not in peer_skill_lower:
            under_bushel.append({
                'skill': skill,
                'reason': 'Hidden differentiator – weave it into your opening story.'
            })
    under_bushel = under_bushel[:5]

    resume_guidance: List[str] = []
    if touchnots:
        missing = ', '.join(item['skill'] for item in touchnots[:2])
        resume_guidance.append(
            f"Add quantified bullets for {missing} – talent partners flag these before screening calls."
        )
    if under_bushel:
        resume_guidance.append(
            f"Promote '{under_bushel[0]['skill']}' in your summary so it is no longer hidden."
        )
    if relationships['similar_titles']:
        resume_guidance.append(
            f"Mirror phrasing from {relationships['similar_titles'][0]} to align with adjacent clusters."
        )

    return {
        'target_title': target_title,
        'job_category': job_category,
        'confidence': float(confidence),
        'similar_titles': relationships['similar_titles'],
        'lateral_moves': relationships['lateral_moves'],
        'advancement_roles': relationships['advancement_roles'],
        'touchpoints': touchpoints[:6],
        'touchnots': touchnots[:6],
        'under_bushel': under_bushel,
        'resume_guidance': resume_guidance,
        'generated_at': datetime.utcnow().isoformat()
    }


def render_job_cloud_panel(
    resume_snapshot: Dict[str, Any],
    resume_skills: List[str],
    selected_job: Optional[Dict[str, Any]],
    analysis_results: Dict[str, Any]
) -> None:
    """Expose job cloud insights inside Coaching Hub."""
    st.markdown("#### ☁️ Job Cloud Signals (Always On)")

    if not (JOB_CLOUD_AVAILABLE and job_cloud_bridge):
        st.info("Job cloud intelligence is offline in this environment. The admin portal pins it always-on in production.")
        return

    if not resume_snapshot and not st.session_state.get('uploaded_resume_content'):
        st.info("Upload your resume on page 09 to unlock personalized job cloud insights.")
        return

    _ensure_job_cloud_tokens()

    default_target = None
    if isinstance(selected_job, dict):
        default_target = selected_job.get('title') or selected_job.get('job_title')
    if not default_target:
        default_target = st.session_state.get('target_job_title')
    if not default_target:
        profile = st.session_state.get('profile_data') or {}
        default_target = (
            analysis_results.get('current_role')
            or derive_current_role(resume_snapshot, analysis_results, profile)
            or profile.get('role_focus')
        )

    if default_target and not st.session_state.get('coaching_job_cloud_target'):
        st.session_state['coaching_job_cloud_target'] = default_target

    target_title = st.text_input(
        "Target interview focus",
        placeholder="Senior Product Manager",
        key='coaching_job_cloud_target'
    ).strip()

    if not st.session_state.get('coaching_job_cloud_focus'):
        st.session_state['coaching_job_cloud_focus'] = 'Touchpoints'

    focus_choice = st.radio(
        "Signal focus",
        options=["Touchpoints", "Gaps", "Hidden strengths"],
        horizontal=True,
        key='coaching_job_cloud_focus'
    )

    resume_text = _derive_resume_text(resume_snapshot)
    run_col, info_col = st.columns([1, 2])
    with run_col:
        refresh_trigger = st.button("Refresh job cloud scan", key='coaching_job_cloud_refresh')
    with info_col:
        st.caption("Powered by the admin job cloud graph · stays online even when other services restart")

    cache: Dict[str, Dict[str, Any]] = st.session_state.setdefault('coaching_job_cloud_cache', {})

    if refresh_trigger:
        if not target_title:
            st.warning("Set a target role before refreshing job cloud signals.")
        else:
            insights = _refresh_job_cloud_snapshot(target_title, resume_text, resume_skills)
            if insights:
                cache[target_title.lower()] = insights
                st.session_state['coaching_job_cloud_active_key'] = target_title.lower()
                st.success("Job cloud scan synced.")
            else:
                st.warning("Job cloud service did not return new data yet.")

    active_key = st.session_state.get('coaching_job_cloud_active_key')
    if not active_key and target_title:
        active_key = target_title.lower()
    if not active_key and cache:
        active_key = next(iter(cache))

    insights = cache.get(active_key) if active_key else None

    if not insights:
        st.caption("Run the job cloud scan once to unlock interview-ready guidance.")
        return

    job_category = insights.get('job_category', insights.get('target_title'))
    confidence_pct = float(insights.get('confidence', 0)) * 100
    st.markdown(
        f"**Cluster:** {job_category} · Confidence {confidence_pct:.0f}% · Target `{insights.get('target_title')}`"
    )

    def _render_chip_row(label: str, values: List[str]):
        if not values:
            return
        chips = ''.join([
            f"<span style='background:#f5f3ff;border:1px solid #ddd;padding:0.25rem 0.65rem;border-radius:999px;" +
            "font-size:0.8rem;margin:0.2rem 0.35rem 0.1rem 0;display:inline-block;'>" + value + "</span>"
            for value in values[:6]
        ])
        st.caption(label)
        st.markdown(f"<div style='margin-bottom:0.5rem;'>{chips}</div>", unsafe_allow_html=True)

    _render_chip_row("Similar titles", insights.get('similar_titles', []))
    _render_chip_row("Lateral moves", insights.get('lateral_moves', []))

    focus_map = {
        'Touchpoints': ('touchpoints', st.success, "Already documented – double down"),
        'Gaps': ('touchnots', st.warning, "Missing signal – add a punchy example"),
        'Hidden strengths': ('under_bushel', st.info, "Hidden strength – promote it early"),
    }
    data_key, renderer, header = focus_map[focus_choice]
    renderer(header)

    entries = insights.get(data_key, [])
    if entries:
        for entry in entries:
            st.markdown(f"- **{entry['skill']}** — {entry['reason']}")
    else:
        st.caption("No signals yet for this filter. Refresh or switch focus.")

    guidance = insights.get('resume_guidance') or []
    if guidance:
        st.markdown("##### 📋 Interview Story Prompts")
        for tip in guidance:
            st.markdown(f"- {tip}")

    generated_at = insights.get('generated_at')
    if generated_at:
        st.caption(f"Synced {generated_at.split('T')[0]}")

# Page configuration
st.set_page_config(
    page_title="🎓 Coaching Hub | IntelliCV-AI",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Authentication check
if not st.session_state.get('authenticated_user'):
    st.error("🔒 Please log in to access Coaching Hub")
    if st.button("🏠 Return to Home"):
        st.switch_page("main.py")
    st.stop()

# Tier check for premium features
user_tier = st.session_state.get('subscription_tier', 'free')
PREMIUM_TIERS = ['monthly_pro', 'annual_pro', 'enterprise_pro']

if user_tier not in PREMIUM_TIERS:
    st.warning("⭐ Coaching Hub requires Premium subscription (£99/month or £299/year)")
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        if st.button("⬆️ Upgrade to Premium", type="primary", use_container_width=True):
            st.switch_page("pages/06_Pricing.py")
    st.stop()

# Initialize coaching session state
if 'coaching_state' not in st.session_state:
    st.session_state.coaching_state = {
        'active_coach': 'interview',
        'interview_sessions': [],
        'career_plans': [],
        'mentorship_connections': [],
        'mentorship_sessions': [],
        'mentor_search_filters': {},
        'mentor_search_results': [],
        'mentorship_interest_requests': [],
        'practice_sessions': [],
        'career_goals': [],
        'chat_history': {
            'interview': [],
            'career': [],
            'mentorship': []
        }
    }

coaching_state = st.session_state.coaching_state
coaching_state.setdefault('interview_sessions', [])
coaching_state.setdefault('practice_sessions', [])
coaching_state.setdefault('career_plans', [])
coaching_state.setdefault('career_goals', [])
coaching_state.setdefault('mentorship_connections', [])
coaching_state.setdefault('mentorship_sessions', [])
coaching_state.setdefault('mentor_search_filters', {})
coaching_state.setdefault('mentor_search_results', [])
coaching_state.setdefault('mentorship_interest_requests', [])

# Title and introduction
st.title("🎓 Coaching Hub")
st.markdown("""
### Your Personal Career Development Center
Access specialized AI coaches for interview preparation, career planning, and mentorship guidance.
Each coach includes a dedicated chatbot for 24/7 personalized support.
""")

# Token cost display
st.info("💎 **Token Cost: 15 tokens** | Includes unlimited coach access + AI chatbot interactions")

profile_data = st.session_state.get('profile_data', {}) if isinstance(st.session_state.get('profile_data'), dict) else {}
resume_snapshot = get_resume_snapshot()
resume_skills = extract_resume_skills(resume_snapshot)
experience_entries = get_experience_entries(resume_snapshot)
analysis_results = st.session_state.get('analysis_results', {})
umarketu_state = st.session_state.get('umarketu_state', {}) if isinstance(st.session_state.get('umarketu_state'), dict) else {}
applications = umarketu_state.get('applications', []) or []
selected_job = umarketu_state.get('selected_job')
fit_analysis = umarketu_state.get('fit_analysis')
user_id = st.session_state.get('user_id', 'demo_user')
token_wallet = st.session_state.get('token_wallet') or {}
addons = st.session_state.get('addons') or {}
mentorship_tokens = int(
    st.session_state.get('mentorship_tokens')
    or addons.get('mentorship_tokens', 0)
    or token_wallet.get('mentorship', 0)
    or 0
)
mentorship_access_override = bool(
    st.session_state.get('mentorship_access')
    or addons.get('mentorship_access')
)
elite_tiers = {'elite_pro', 'enterprise_pro'}
has_mentorship_access = mentorship_access_override or mentorship_tokens > 0 or user_tier in elite_tiers
jd_required_skills: List[str] = []
if isinstance(selected_job, dict):
    jd_data = selected_job.get('jd_data') or {}
    raw_skills = jd_data.get('required_skills') or []
    jd_required_skills = [skill for skill in raw_skills if isinstance(skill, str)]

# Quick metrics (derived from live data)
practice_sessions = coaching_state.get('practice_sessions', [])
interview_preps = len(practice_sessions)
career_plan_count = len(coaching_state.get('career_plans', []))
mentorship_hours = sum((conn.get('hours_logged') or 0) for conn in coaching_state.get('mentorship_connections', []))

application_statuses = [str(app.get('status', '')).lower() for app in applications]
offer_count = sum(1 for status in application_statuses if 'offer' in status)
success_rate_value = (offer_count / len(applications) * 100) if applications else None

col1, col2, col3, col4 = st.columns(4)
with col1:
    st.metric("🎤 Interview Preps", interview_preps, help="Practice sessions logged in this workspace")
with col2:
    st.metric("📊 Career Plans", career_plan_count, help="Saved personalized plans")
with col3:
    mentorship_display = f"{mentorship_hours:.1f}h" if mentorship_hours else "0h"
    st.metric("🤝 Mentorship Hours", mentorship_display, help="Hours recorded with real mentors")
with col4:
    success_display = f"{success_rate_value:.0f}%" if success_rate_value is not None else "—"
    st.metric("⭐ Offer Rate", success_display, help="Offers / total tracked applications")

st.markdown("---")

# Navigation tabs for coaching specialists
tab1, tab2, tab3 = st.tabs([
    "🎤 Interview Coach",
    "📊 Career Coach",
    "🤝 Mentorship Coach"
])

# ===========================
# TAB 1: INTERVIEW COACH
# ===========================
subtab1 = subtab2 = subtab3 = subtab4 = None
with tab1:
    st.header("🎤 Interview Coach")
    st.markdown("**AI-powered interview preparation with real-time practice and feedback**")

    render_job_cloud_panel(resume_snapshot, resume_skills, selected_job, analysis_results)
    st.markdown("---")

    # Interview Coach sections
    subtab1, subtab2, subtab3, subtab4 = st.tabs([
        "💬 Chat with Coach",
        "📋 Interview Prep",
        "🎯 Practice Sessions",
        "📊 Performance Analytics"
    ])

    with subtab1:
        st.subheader("💬 Interview Coach Chatbot")
        st.markdown("Ask your interview coach anything about preparation, strategies, or specific questions.")

        # Initialize interview chatbot history
        if 'interview' not in st.session_state.coaching_state['chat_history']:
            st.session_state.coaching_state['chat_history']['interview'] = [
                {"role": "assistant", "content": "👋 Hi! I'm your AI Interview Coach. I can help you prepare for interviews, practice common questions, and provide feedback on your responses. What interview are you preparing for?"}
            ]

        # Display chat messages
        for message in st.session_state.coaching_state['chat_history']['interview']:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])

        # Chat input
        if prompt := st.chat_input("Ask about interview preparation, common questions, strategies..."):
            # Add user message
            st.session_state.coaching_state['chat_history']['interview'].append({"role": "user", "content": prompt})
            with st.chat_message("user"):
                st.markdown(prompt)

            # AI response using portal_bridge ChatService
            if PORTAL_BRIDGE_AVAILABLE and chat_service:
                try:
                    # Get context from session state
                    context = {
                        "coach_type": "interview",
                        "user_tier": user_tier,
                        "resume_data": st.session_state.get('resume_data', {}),
                        "target_role": st.session_state.get('target_job_title', 'Not specified')
                    }

                    # Call admin AI chatbot via portal_bridge
                    ai_payload = chat_service.ask(
                        question=prompt,
                        context=context,
                        user_id=user_id
                    )

                    if isinstance(ai_payload, dict):
                        response_text = ai_payload.get('content') or ai_payload.get('answer') or ai_payload.get('message') or "AI coach responded with no content."
                    else:
                        response_text = str(ai_payload)

                    with st.chat_message("assistant"):
                        st.markdown(response_text)

                    st.session_state.coaching_state['chat_history']['interview'].append({"role": "assistant", "content": response_text})

                except Exception as e:
                    # Fallback response if portal_bridge fails
                    st.error(f"⚠️ AI Coach temporarily unavailable: {str(e)}")
                    skills_preview = ", ".join(resume_skills[:3]) if resume_skills else "Upload a resume to unlock personalized prompts."
                    fallback_response = (
                        "Live AI coaching is offline right now. Based on your uploaded resume we detected "
                        f"{len(resume_skills)} documented skills: {skills_preview}. Update your resume on page 09 "
                        "to enrich this guidance."
                    )
                    with st.chat_message("assistant"):
                        st.markdown(fallback_response)
                    st.session_state.coaching_state['chat_history']['interview'].append({"role": "assistant", "content": fallback_response})
            else:
                resume_summary = resume_snapshot.get('metadata', {}).get('summary') or "Upload a resume on page 09 to unlock targeted advice."
                offline_response = (
                    "AI Interview Coach requires the admin AI bridge. Once it's online I'll tailor prompts to your resume. "
                    f"For now, focus on reinforcing your documented strengths: {', '.join(resume_skills[:5]) if resume_skills else resume_summary}."
                )
                st.session_state.coaching_state['chat_history']['interview'].append({"role": "assistant", "content": offline_response})
                with st.chat_message("assistant"):
                    st.markdown(offline_response)

        # Quick action buttons
        st.markdown("---")
        st.markdown("**🚀 Quick Actions**")
        col1, col2, col3 = st.columns(3)
        with col1:
            if st.button("📚 Common Questions Library", use_container_width=True):
                if QUESTION_LIBRARY_AVAILABLE:
                    question_pack = filter_interview_questions(
                        seniority=infer_seniority(selected_job, analysis_results, resume_snapshot),
                        role_type=infer_role_type(selected_job, resume_snapshot),
                        limit=10,
                    )
                    if question_pack:
                        preview = "\n".join(
                            [
                                f"{idx}. {question['text']}"
                                + (f" (Hint: {question['coachingHint']})" if question.get('coachingHint') else "")
                                for idx, question in enumerate(question_pack, 1)
                            ]
                        )
                        quick_content = (
                            "Here are curated questions to rehearse right now:\n" + preview
                        )
                    else:
                        quick_content = (
                            "Question library is online but no prompts matched your filters. Head to Interview Prep to adjust the selectors."
                        )
                else:
                    quick_content = (
                        "Interview question library is offline. Sync the shared module to enable curated prompts."
                    )

                st.session_state.coaching_state['chat_history']['interview'].append({
                    "role": "assistant",
                    "content": quick_content
                })
                st.rerun()
        with col2:
            if st.button("🎯 STAR Method Guide", use_container_width=True):
                st.session_state.coaching_state['chat_history']['interview'].append({
                    "role": "assistant",
                    "content": "**STAR Method Framework:**\n\n**S**ituation: Set the context\n**T**ask: Describe your responsibility\n**A**ction: Explain what you did\n**R**esult: Share the outcome\n\nLet's practice with an example..."
                })
                st.rerun()
        with col3:
            if st.button("🔄 Start Mock Interview", use_container_width=True):
                st.session_state.coaching_state['chat_history']['interview'].append({
                    "role": "assistant",
                    "content": "Great! Let's start your mock interview. I'll ask you 10 questions. Ready? Here's the first: 'Tell me about yourself.'"
                })
                st.rerun()

    with subtab2:
        st.subheader("📋 Interview Preparation Hub")

        st.markdown("#### 🧠 Skill-Based Question Bank")
        if resume_skills:
            target_company = (
                selected_job.get('company')
                if isinstance(selected_job, dict) and selected_job.get('company')
                else "your target company"
            )
            question_rows = []
            for skill in resume_skills[:8]:
                question_rows.append({
                    'Skill': skill,
                    'Question': (
                        f"Describe a recent situation where you applied **{skill}** to deliver measurable impact. "
                        f"How would you tailor that story for {target_company}?"
                    )
                })

            if experience_entries:
                latest_company = experience_entries[0].get('company') or target_company
                question_rows.append({
                    'Skill': 'Leadership & Collaboration',
                    'Question': (
                        f"Share a STAR story from {latest_company} where you influenced cross-functional teams. "
                        "Highlight the metrics you improved."
                    )
                })

            st.dataframe(pd.DataFrame(question_rows), use_container_width=True, hide_index=True)
        else:
            st.info("Upload your resume on page 09 to generate a personalized interview question bank.")

        if QUESTION_LIBRARY_AVAILABLE:
            st.markdown("#### 🎤 Interview Question Library")
            role_guess = infer_role_type(selected_job, resume_snapshot)
            seniority_guess = infer_seniority(selected_job, analysis_results, resume_snapshot)

            category_pairs: List[Tuple[str, Optional[str]]] = [("All categories", None)]
            for value in sorted({question['category'] for question in INTERVIEW_QUESTION_LIBRARY}):
                category_pairs.append((value.replace('_', ' ').title(), value))

            seniority_pairs: List[Tuple[str, Optional[str]]] = [("Any seniority", None)]
            seniority_pairs.extend(
                (label.title(), label)
                for label in ("junior", "mid", "senior", "exec")
            )

            role_pairs: List[Tuple[str, Optional[str]]] = [
                ("Any role", 'any'),
                ("Engineering", 'engineering'),
                ("Product", 'product'),
                ("Data", 'data'),
                ("ML / AI", 'ml'),
            ]

            def _option_index(pairs: Sequence[Tuple[str, Optional[str]]], target: Optional[str]) -> int:
                for idx, (_, value) in enumerate(pairs):
                    if value == target:
                        return idx
                return 0

            filter_col1, filter_col2, filter_col3, filter_col4 = st.columns(4)
            with filter_col1:
                category_label = st.selectbox(
                    "Category",
                    [label for label, _ in category_pairs],
                    index=_option_index(category_pairs, 'behavioral'),
                )
            with filter_col2:
                seniority_label = st.selectbox(
                    "Seniority",
                    [label for label, _ in seniority_pairs],
                    index=_option_index(seniority_pairs, seniority_guess if seniority_guess != 'any' else None),
                )
            with filter_col3:
                role_label = st.selectbox(
                    "Role Focus",
                    [label for label, _ in role_pairs],
                    index=_option_index(role_pairs, role_guess),
                )
            with filter_col4:
                question_limit = st.slider("Limit", 5, 20, 10, 1)

            category_value = dict(category_pairs)[category_label]
            seniority_value = dict(seniority_pairs)[seniority_label]
            role_value = dict(role_pairs)[role_label]

            filtered_questions = filter_interview_questions(
                category=category_value,
                seniority=seniority_value,
                role_type=role_value,
                limit=question_limit,
            )

            if filtered_questions:
                library_rows = [
                    {
                        'Category': question['category'].replace('_', ' ').title(),
                        'Seniority': question['seniority'].title(),
                        'Question': question['text'],
                        'Coaching Hint': question.get('coachingHint') or '—',
                    }
                    for question in filtered_questions
                ]
                st.dataframe(pd.DataFrame(library_rows), use_container_width=True, hide_index=True)
                st.caption(
                    f"Showing {len(filtered_questions)} of {len(INTERVIEW_QUESTION_LIBRARY)} curated questions."
                )
            else:
                st.info("No questions match those filters yet. Adjust the selections to explore the library.")
        else:
            st.warning("Question library unavailable. Ensure the shared module is synced to enable curated prompts.")

        col1, col2 = st.columns([1, 1])

        with col1:
            st.markdown("#### 🎯 Upcoming Interviews")

            # Add new interview
            with st.expander("➕ Add Interview", expanded=False):
                int_company = st.text_input("Company", placeholder="e.g., Google, Amazon")
                int_position = st.text_input("Position", placeholder="e.g., Senior ML Engineer")
                int_date = st.date_input("Interview Date")
                int_type = st.selectbox("Interview Type", [
                    "Phone Screen", "Technical", "Behavioral", "System Design",
                    "Coding Challenge", "Panel", "Final Round"
                ])

                if st.button("💾 Save Interview", type="primary"):
                    if not int_company or not int_position:
                        st.error("❌ Company and position are required")
                    else:
                        coaching_state['interview_sessions'].append({
                            'company': int_company.strip(),
                            'position': int_position.strip(),
                            'date': datetime.combine(int_date, datetime.min.time()).isoformat(),
                            'type': int_type,
                            'status': '🟡 Preparing'
                        })
                        st.success("✅ Interview added to preparation schedule!")
                        st.rerun()

            upcoming_rows = build_upcoming_interviews(coaching_state['interview_sessions'], applications)
            if upcoming_rows:
                st.markdown("---")
                st.dataframe(pd.DataFrame(upcoming_rows), use_container_width=True)
            else:
                st.info("No upcoming interviews recorded yet. Add one above or log interviews from the Application Tracker.")

        with col2:
            st.markdown("#### 📚 Preparation Materials")

            prep_category = st.selectbox("Category", [
                "Company Research", "Technical Questions", "Behavioral Questions",
                "System Design", "Coding Practice", "Case Studies"
            ])

            jd_skills = jd_required_skills

            if prep_category == "Company Research":
                if selected_job:
                    company_name = selected_job.get('company', 'Company')
                    st.markdown(f"**Company:** {company_name}")
                    if jd_skills:
                        st.markdown("**What to study from the JD:**")
                        for skill in jd_skills[:6]:
                            st.markdown(f"- Demonstrate impact using **{skill}**")
                    else:
                        st.info("Run Fit Analysis in UMarketU Suite to pull full JD data.")
                else:
                    st.info("Link an application in UMarketU Suite to generate company-specific intel.")

            elif prep_category == "Technical Questions":
                if resume_skills:
                    st.markdown("**Targeted prompts based on your documented skills:**")
                    for idx, skill in enumerate(resume_skills[:6], 1):
                        st.markdown(f"{idx}. Describe a measurable result you delivered using **{skill}**.")
                else:
                    st.info("Upload your resume (page 09) to extract technical focus areas.")

            elif prep_category == "Behavioral Questions":
                if experience_entries:
                    st.markdown("**Build STAR stories from your actual experience:**")
                    for entry in experience_entries[:4]:
                        company = entry.get('company', 'your team')
                        title = entry.get('title') or entry.get('role', 'your role')
                        st.markdown(f"- Share a time at **{company}** where you excelled as {title}, focusing on Situation → Task → Action → Result.")
                else:
                    st.info("Add experience entries to your resume to unlock behavioral prompts.")

            elif prep_category == "System Design":
                if jd_skills:
                    st.markdown("**Systems to rehearse based on the target JD:**")
                    for skill in jd_skills[:5]:
                        st.markdown(f"- How would you architect a scalable solution heavily reliant on **{skill}**?")
                else:
                    st.info("Select a job in UMarketU Suite to surface system design expectations.")

            elif prep_category == "Coding Practice":
                coding_skills = [skill for skill in resume_skills if skill.lower() in {'python', 'java', 'c++', 'sql', 'javascript'}]
                if coding_skills:
                    st.markdown("**Target languages from your resume:**")
                    for skill in coding_skills:
                        st.markdown(f"- Implement a recent project snippet in **{skill}** emphasizing readability and tests.")
                else:
                    st.info("Tag programming languages in your resume skills list to customize this list.")

            elif prep_category == "Case Studies":
                if experience_entries:
                    st.markdown("**Use your real projects as the base case:**")
                    for entry in experience_entries[:3]:
                        project = entry.get('summary') or entry.get('description') or "Document a business problem you solved."
                        st.markdown(f"- Be ready to explain: {project}")
                else:
                    st.info("Upload at least one project/experience to generate case study prompts.")

    with subtab3:
        st.subheader("🎯 Practice Sessions & Mock Interviews")

        st.markdown("#### 🎬 Start New Practice Session")

        col1, col2 = st.columns(2)
        with col1:
            practice_type = st.selectbox("Session Type", [
                "Quick Practice (5 questions)",
                "Standard Mock (10 questions)",
                "Full Interview (20 questions)",
                "Custom Session"
            ])
        with col2:
            focus_area = st.selectbox("Focus Area", [
                "Technical Skills",
                "Behavioral/STAR",
                "Company-Specific",
                "Mixed (Balanced)"
            ])

        confidence_default = min(100, int(analysis_results.get('basic_score', 70) or 70))
        confidence_score = st.slider("Self-assessed readiness (%)", 0, 100, confidence_default, 5)
        practice_notes = st.text_input("Session focus notes", placeholder="e.g., Deep dive into system design trade-offs")

        question_count_map = {
            "Quick Practice (5 questions)": 5,
            "Standard Mock (10 questions)": 10,
            "Full Interview (20 questions)": 20,
            "Custom Session": 8
        }
        duration_map = {
            "Quick Practice (5 questions)": 20,
            "Standard Mock (10 questions)": 45,
            "Full Interview (20 questions)": 90,
            "Custom Session": 30
        }

        if st.button("🚀 Start Practice Session", type="primary", use_container_width=True):
            with st.spinner("Logging your practice session and priming the coach..."):
                session_record = {
                    'id': str(uuid4()),
                    'type': practice_type,
                    'focus': focus_area,
                    'question_count': question_count_map.get(practice_type, 8),
                    'duration_minutes': duration_map.get(practice_type, 30),
                    'confidence_score': confidence_score,
                    'notes': practice_notes.strip(),
                    'created_at': datetime.now().isoformat()
                }
                coaching_state['practice_sessions'].append(session_record)
                st.success("✅ Practice session logged! Open the Interview Coach chat for tailored prompts.")
                st.session_state.coaching_state['chat_history']['interview'].append({
                    "role": "assistant",
                    "content": (
                        f"🎯 **{practice_type} - {focus_area}**\n\n"
                        "Session logged with your readiness score. I'm ready to start when you are."
                    )
                })

        st.markdown("---")
        st.markdown("#### 📊 Recent Practice Sessions")

        if coaching_state['practice_sessions']:
            session_rows = []
            for session in reversed(coaching_state['practice_sessions'][-10:]):
                session_rows.append({
                    'Date': session['created_at'][:10],
                    'Type': session['type'],
                    'Focus': session['focus'],
                    'Questions': session['question_count'],
                    'Confidence': f"{session.get('confidence_score', 0)}%",
                    'Duration': f"{session.get('duration_minutes', 0)}m",
                    'Notes': session.get('notes', '')
                })
            st.dataframe(pd.DataFrame(session_rows), use_container_width=True)
        else:
            st.info("No practice sessions logged yet. Start one above to see your history here.")

    with subtab4:
        st.subheader("📊 Performance Analytics")

        col1, col2 = st.columns(2)

        with col1:
            # Performance metrics
            st.markdown("#### 📈 Overall Performance")

            metrics_col1, metrics_col2 = st.columns(2)
            with metrics_col1:
                success_display = f"{success_rate_value:.0f}%" if success_rate_value is not None else "—"
                st.metric("Offer Rate", success_display)
                practice_hours = sum(session.get('duration_minutes', 0) for session in coaching_state['practice_sessions']) / 60
                st.metric("Practice Hours", f"{practice_hours:.1f}h")
            with metrics_col2:
                if coaching_state['practice_sessions']:
                    avg_conf = mean(session.get('confidence_score', 0) for session in coaching_state['practice_sessions'])
                    st.metric("Avg Confidence", f"{avg_conf:.0f}%")
                else:
                    st.metric("Avg Confidence", "—")
                st.metric("Sessions Logged", len(coaching_state['practice_sessions']))

            # Performance trend chart
            st.markdown("#### 📊 Score Trend")
            if coaching_state['practice_sessions']:
                trend_data = pd.DataFrame({
                    'Session': list(range(1, len(coaching_state['practice_sessions']) + 1)),
                    'Confidence': [session.get('confidence_score', 0) for session in coaching_state['practice_sessions']]
                })
                fig = px.line(trend_data, x='Session', y='Confidence',
                              title='Self-assessed Readiness Over Time', markers=True)
                fig.update_layout(height=300, yaxis=dict(range=[0, 100]))
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Log at least one practice session to see your readiness trend.")

        with col2:
            # Category breakdown
            st.markdown("#### 🎯 Performance by Category")

            if coaching_state['practice_sessions']:
                category_df = pd.DataFrame(coaching_state['practice_sessions'])
                grouped = category_df.groupby('focus')['confidence_score'].mean().reset_index().rename(columns={'confidence_score': 'Confidence'})
                fig = px.bar(grouped, x='focus', y='Confidence',
                             title='Average Confidence by Focus Area', color='Confidence',
                             color_continuous_scale='RdYlGn')
                fig.update_layout(height=300, xaxis_title='', showlegend=False, yaxis=dict(range=[0, 100]))
                st.plotly_chart(fig, use_container_width=True)

                st.markdown("#### 🎓 Areas for Improvement")
                low_conf = grouped.sort_values('Confidence').head(3)
                if not low_conf.empty:
                    for _, row in low_conf.iterrows():
                        st.markdown(f"- 🔸 **{row['focus']}**: average confidence {row['Confidence']:.0f}% — schedule another focused session.")
                else:
                    st.success("All focus areas are trending above 80% confidence.")
            else:
                st.info("Complete a practice session to unlock category analytics.")

# ===========================
# TAB 2: CAREER COACH
# ===========================
with tab2:
    st.header("📊 Career Coach")
    st.markdown("**AI-powered career planning, skill development, and trajectory optimization**")

    # Career Coach sections
    subtab1, subtab2, subtab3, subtab4 = st.tabs([
        "💬 Chat with Coach",
        "🗺️ Career Roadmap",
        "📈 Skill Development",
        "🎯 Goal Tracking"
    ])

    with subtab1:
        st.subheader("💬 Career Coach Chatbot")
        st.markdown("Get personalized career advice, planning guidance, and skill recommendations.")

        # Initialize career chatbot history
        if 'career' not in st.session_state.coaching_state['chat_history']:
            st.session_state.coaching_state['chat_history']['career'] = [
                {"role": "assistant", "content": "👋 Hi! I'm your AI Career Coach. I can help you plan your career path, develop new skills, and achieve your professional goals. What would you like to work on today?"}
            ]

        # Display chat messages
        for message in st.session_state.coaching_state['chat_history']['career']:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])

        # Chat input
        if prompt := st.chat_input("Ask about career planning, skill gaps, next steps..."):
            # Add user message
            st.session_state.coaching_state['chat_history']['career'].append({"role": "user", "content": prompt})
            with st.chat_message("user"):
                st.markdown(prompt)

            # AI response using portal_bridge ChatService
            if PORTAL_BRIDGE_AVAILABLE and chat_service:
                try:
                    # Get context for career coaching
                    context = {
                        "coach_type": "career",
                        "user_tier": user_tier,
                        "resume_data": st.session_state.get('resume_data', {}),
                        "current_role": st.session_state.get('current_role', 'Not specified'),
                        "career_goals": st.session_state.get('career_goals', [])
                    }

                    # Call admin AI chatbot via portal_bridge
                    ai_payload = chat_service.ask(
                        question=prompt,
                        context=context,
                        user_id=user_id
                    )

                    if isinstance(ai_payload, dict):
                        response_text = ai_payload.get('content') or ai_payload.get('answer') or ai_payload.get('message') or "AI coach responded with no content."
                    else:
                        response_text = str(ai_payload)

                    with st.chat_message("assistant"):
                        st.markdown(response_text)

                    st.session_state.coaching_state['chat_history']['career'].append({"role": "assistant", "content": response_text})

                except Exception as e:
                    # Fallback response
                    st.error(f"⚠️ Career Coach temporarily unavailable: {str(e)}")
                    total_years = get_total_experience_years(resume_snapshot, analysis_results) or 0
                    fallback_response = (
                        "Live coaching is offline. Your uploaded resume shows "
                        f"~{total_years:.1f} years of experience and {len(resume_skills)} documented skills. "
                        "Capture your 3-year goal in the Goal Tracking tab and I'll sync once AI access is restored."
                    )
                    with st.chat_message("assistant"):
                        st.markdown(fallback_response)
                    st.session_state.coaching_state['chat_history']['career'].append({"role": "assistant", "content": fallback_response})
            else:
                next_steps = (
                    "The AI bridge is offline. Use the Skill Development tab to log your learning plan. "
                    "Once the admin AI reconnects, I'll augment it with peer benchmarking."
                )
                st.session_state.coaching_state['chat_history']['career'].append({"role": "assistant", "content": next_steps})
                with st.chat_message("assistant"):
                    st.markdown(next_steps)

        # Quick actions
        st.markdown("---")
        st.markdown("**🚀 Quick Actions**")
        col1, col2, col3 = st.columns(3)
        with col1:
            if st.button("🗺️ Create Career Plan", use_container_width=True):
                st.session_state.coaching_state['chat_history']['career'].append({
                    "role": "assistant",
                    "content": "Let's build your career plan! First, tell me your 3-year goal. What role do you want to be in?"
                })
                st.rerun()
        with col2:
            if st.button("📊 Analyze Skill Gaps", use_container_width=True):
                st.session_state.coaching_state['chat_history']['career'].append({
                    "role": "assistant",
                    "content": "**Skill Gap Analysis:**\n\n✅ **Strengths**: Python, ML, Data Analysis\n🔸 **Develop**: Cloud (AWS/Azure), Leadership, System Design\n⚠️ **Critical**: DevOps, Team Management\n\nShall I create a learning plan?"
                })
                st.rerun()
        with col3:
            if st.button("🎯 Set New Goal", use_container_width=True):
                st.session_state.coaching_state['chat_history']['career'].append({
                    "role": "assistant",
                    "content": "Great! Let's set a SMART goal (Specific, Measurable, Achievable, Relevant, Time-bound). What's your objective?"
                })
                st.rerun()

    with subtab2:
        st.subheader("🗺️ Career Roadmap & Trajectory")

        col1, col2 = st.columns([1, 1])

        with col1:
            st.markdown("#### 🎯 Current Position")
            current_role = derive_current_role(resume_snapshot, analysis_results, profile_data)
            current_entry = experience_entries[0] if experience_entries else {}
            start_date = safe_parse_date(current_entry.get('start_date') or current_entry.get('start'))
            end_date = safe_parse_date(current_entry.get('end_date') or current_entry.get('end')) or datetime.now()
            tenure_years = None
            if start_date:
                tenure_years = max((end_date - start_date).days / 365, 0)

            level = current_entry.get('level') or resume_snapshot.get('metadata', {}).get('level') or profile_data.get('career_level')
            salary = (
                profile_data.get('current_salary')
                or resume_snapshot.get('metadata', {}).get('compensation')
                or st.session_state.get('compensation_expectations')
            )

            if current_role:
                tenure_label = f"Tenure: {tenure_years:.1f} years" if tenure_years else "Tenure data not captured"
                level_label = f"Level: {level}" if level else "Level: —"
                salary_label = f"Salary: {salary}" if salary else "Salary: —"
                st.info(f"**{current_role}**\n\n{tenure_label} | {level_label} | {salary_label}")
            else:
                st.info("Link your resume (page 09) to surface your current role and tenure.")

            st.markdown("#### 📊 Career Trajectory Analysis")
            score_components = []
            if fit_analysis and fit_analysis.get('fit_score') is not None:
                score_components.append(fit_analysis['fit_score'] / 10)
            if analysis_results.get('basic_score') is not None:
                score_components.append(analysis_results['basic_score'] / 10)
            if practice_sessions:
                avg_conf = mean(session.get('confidence_score', 0) for session in practice_sessions)
                score_components.append(avg_conf / 10)

            if score_components:
                trajectory_score = min(10, sum(score_components) / len(score_components))
                st.metric("Trajectory Score", f"{trajectory_score:.1f}/10")
            else:
                st.metric("Trajectory Score", "—")

            # Progress bars
            st.markdown("**Growth Dimensions:**")
            technical_index = min(1.0, len(resume_skills) / 20) if resume_skills else 0.0
            leadership_index = compute_leadership_index(experience_entries)
            visibility_index = compute_visibility_index(resume_snapshot)
            strategy_index = compute_strategy_index(resume_snapshot)

            st.progress(technical_index, text=f"Technical Excellence: {technical_index * 100:.0f}%")
            st.progress(leadership_index, text=f"Leadership Impact: {leadership_index * 100:.0f}%")
            st.progress(visibility_index, text=f"Industry Visibility: {visibility_index * 100:.0f}%")
            st.progress(strategy_index, text=f"Strategic Thinking: {strategy_index * 100:.0f}%")

        with col2:
            st.markdown("#### 🚀 Recommended Career Paths")

            paths: List[Dict[str, Any]] = []
            leadership_index = compute_leadership_index(experience_entries)
            if leadership_index >= 0.3:
                paths.append({
                    'path': 'Technical Leadership',
                    'probability': f"{int(leadership_index * 100)}%",
                    'timeline': '12-18 months',
                    'next_role': 'Lead ' + (current_role or 'Engineer'),
                    'requirements': [
                        'Document at least two initiatives where you owned architecture decisions',
                        'Mentor teammates and capture outcomes in your resume',
                        'Show cross-functional stakeholder wins'
                    ]
                })

            if any('manage' in (entry.get('title', '').lower() or '') for entry in experience_entries):
                paths.append({
                    'path': 'People Management',
                    'probability': '60%',
                    'timeline': '18-24 months',
                    'next_role': 'Engineering Manager',
                    'requirements': [
                        'Highlight team leadership outcomes in resume bullets',
                        'Complete a management fundamentals course',
                        'Show evidence of performance reviews or coaching'
                    ]
                })

            ml_skills = [skill for skill in resume_skills if 'ml' in skill.lower() or 'ai' in skill.lower()]
            if ml_skills:
                paths.append({
                    'path': 'Deep Specialist',
                    'probability': f"{min(90, 40 + len(ml_skills) * 5)}%",
                    'timeline': '24-36 months',
                    'next_role': 'Principal ' + (current_role or 'Specialist'),
                    'requirements': [
                        'Publish thought leadership or conference talks',
                        'Show measurable innovation metrics in resume',
                        'Document advanced research or patents'
                    ]
                })

            if paths:
                for i, path in enumerate(paths, 1):
                    with st.expander(f"Path {i}: {path['path']} ({path['probability']} match)"):
                        st.markdown(f"**Next Role**: {path['next_role']}")
                        st.markdown(f"**Timeline**: {path['timeline']}")
                        st.markdown("**Requirements:**")
                        for req in path['requirements']:
                            st.markdown(f"- {req}")
            else:
                st.info("Upload a resume and run Fit Analysis to generate personalized career paths.")

        # Roadmap visualization
        st.markdown("---")
        st.markdown("#### 🗺️ 5-Year Career Roadmap")

        roadmap_data = pd.DataFrame({
            'Year': ['2025', '2026', '2027', '2028', '2029', '2030'],
            'Role': ['Senior ML Engineer', 'Lead ML Engineer', 'Staff ML Engineer', 'Principal Engineer', 'Distinguished Engineer', 'VP Engineering'],
            'Salary': [85000, 110000, 140000, 175000, 220000, 280000]
        })

        fig = px.line(roadmap_data, x='Year', y='Salary', text='Role',
                     title='Projected Career & Salary Growth',
                     markers=True)
        fig.update_traces(textposition='top center')
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)

    with subtab3:
        st.subheader("📈 Skill Development Plan")

        st.markdown("#### 🎯 Active Learning Paths")

        tracked_skills: List[str] = []
        if resume_skills:
            tracked_skills.extend(resume_skills[:5])
        if jd_required_skills:
            for skill in jd_required_skills:
                if skill not in tracked_skills:
                    tracked_skills.append(skill)
        tracked_skills = tracked_skills[:8]

        jd_skill_set = {skill.lower() for skill in jd_required_skills}
        skill_plan_df = None
        priority_rows: List[Dict[str, Any]] = []
        peer_coverage = compute_peer_skill_coverage(tracked_skills, user_id) if tracked_skills else {}

        if tracked_skills:
            plan_rows: List[Dict[str, Any]] = []
            for skill in tracked_skills:
                current_score = estimate_skill_strength(skill, resume_skills, experience_entries)
                target_score = 90 if skill.lower() in jd_skill_set else 80
                gap = max(target_score - current_score, 0)
                plan_rows.append({
                    'Skill': skill,
                    'Current': round(current_score, 1),
                    'Target': target_score,
                    'Gap': round(gap, 1),
                    'Peer Coverage %': round(peer_coverage.get(skill.lower(), 0.0), 1) if peer_coverage else None
                })
            skill_plan_df = pd.DataFrame(plan_rows)
            priority_rows = sorted(plan_rows, key=lambda row: row['Gap'], reverse=True)

        col1, col2 = st.columns([2, 1])

        with col1:
            if skill_plan_df is not None and not skill_plan_df.empty:
                fig = go.Figure()
                fig.add_trace(go.Bar(name='Current Level', x=skill_plan_df['Skill'], y=skill_plan_df['Current'], marker_color='lightblue'))
                fig.add_trace(go.Bar(name='Target Level', x=skill_plan_df['Skill'], y=skill_plan_df['Target'], marker_color='darkblue'))
                fig.update_layout(title='Skills: Current vs Target', barmode='group', height=320)
                st.plotly_chart(fig, use_container_width=True)
                st.dataframe(
                    skill_plan_df[['Skill', 'Current', 'Target', 'Gap', 'Peer Coverage %']],
                    use_container_width=True,
                    hide_index=True
                )
            else:
                st.info("Upload a resume and run a JD fit analysis to surface personalized learning paths.")

        with col2:
            st.markdown("**Priority Skills**")
            if priority_rows:
                for idx, row in enumerate(priority_rows[:4], 1):
                    timeline = "4 weeks" if row['Gap'] <= 10 else "8 weeks" if row['Gap'] <= 20 else "12 weeks"
                    peer_note = "" if row.get('Peer Coverage %') is None else f" | Peers: {row['Peer Coverage %']:.0f}%"
                    badge = "🟢" if row['Gap'] <= 10 else "🟡" if row['Gap'] <= 20 else "🔴"
                    st.markdown(
                        f"{idx}. {badge} **{row['Skill']}** — Gap {row['Gap']:.0f}% ({timeline}){peer_note}"
                    )
            else:
                st.info("Once resume data is available you'll see gap-driven priorities here.")

        st.markdown("---")
        st.markdown("#### 📚 Recommended Learning Resources")

        top_resources: List[Tuple[str, Dict[str, str]]] = []
        if priority_rows:
            top_resources = [(row['Skill'], recommend_learning_resource(row['Skill'])) for row in priority_rows[:3]]

        learning_tab1, learning_tab2, learning_tab3 = st.tabs(["Courses", "Certifications", "Books"])

        with learning_tab1:
            if priority_rows:
                st.markdown("**🎓 Top Courses for Your Current Gaps**")
                for skill, resources in top_resources:
                    st.markdown(f"- **{skill}** → {resources['course']}")
            else:
                st.info("Upload a resume or link a JD to unlock course recommendations.")

        with learning_tab2:
            if priority_rows:
                st.markdown("**📜 Certifications That Move the Needle**")
                for skill, resources in top_resources:
                    st.markdown(f"- **{skill}** → {resources['certification']}")
            else:
                st.info("No live skills detected yet. Sync your resume to map certifications.")

        with learning_tab3:
            if priority_rows:
                st.markdown("**📖 Deep Dives & Playbooks**")
                for skill, resources in top_resources:
                    st.markdown(f"- **{skill}** → {resources['book']}")
            else:
                st.info("Upload resume data to curate reading lists tied to your goals.")

    with subtab4:
        st.subheader("🎯 Goal Tracking & Progress")

        # Active goals
        st.markdown("#### 📋 Active Career Goals")

        goals_data = [
            {
                "Goal": "Achieve AWS Solutions Architect certification",
                "Category": "Technical",
                "Deadline": "2025-12-31",
                "Progress": 65,
                "Status": "🟡 In Progress"
            },
            {
                "Goal": "Lead cross-functional ML project",
                "Category": "Leadership",
                "Deadline": "2026-03-31",
                "Progress": 40,
                "Status": "🟢 On Track"
            },
            {
                "Goal": "Mentor 3 junior engineers",
                "Category": "Leadership",
                "Deadline": "2025-11-30",
                "Progress": 85,
                "Status": "🟢 On Track"
            }
        ]

        for goal in goals_data:
            with st.expander(f"{goal['Status']} {goal['Goal']}", expanded=True):
                col1, col2, col3 = st.columns([2, 1, 1])
                with col1:
                    st.progress(goal['Progress']/100, text=f"Progress: {goal['Progress']}%")
                with col2:
                    st.markdown(f"**Category**: {goal['Category']}")
                with col3:
                    st.markdown(f"**Due**: {goal['Deadline']}")

        # Add new goal
        st.markdown("---")
        with st.expander("➕ Add New Goal"):
            goal_name = st.text_input("Goal Description")
            goal_category = st.selectbox("Category", ["Technical", "Leadership", "Networking", "Personal Brand"])
            goal_deadline = st.date_input("Target Deadline")

            if st.button("💾 Save Goal", type="primary"):
                st.success("✅ Goal added to tracking!")

# ===========================
# TAB 3: MENTORSHIP COACH
# ===========================
with tab3:
    st.header("🤝 Mentorship Coach")
    st.markdown("**AI-powered mentor matching, session management, and growth tracking**")

    st.info("""
    📋 **Active in a mentorship?** Access your full mentorship dashboard:
    - View agreements and signed requirement documents
    - Track progress and milestones
    - Complete assignments and Q&A from your mentor
    - Review session notes and communicate
    """)

    dashboard_label = "📋 Open My Mentorship Dashboard" if has_mentorship_access else "📋 Preview Mentorship Dashboard"
    if st.button(dashboard_label, type="primary", use_container_width=True):
        if has_mentorship_access:
            st.info("🔗 Opening mentee dashboard... (Link to mentor_portal/pages/04_Mentee_Agreements_Progress.py)")
            st.caption("This links to the mentor portal's mentee-facing page for full agreement & progress tracking")
        else:
            st.warning("Mentorship dashboard unlocks once you add mentorship tokens or upgrade to Elite Pro.")

    st.markdown("---")

    if not has_mentorship_access:
        st.warning("Mentorship Coach is an Elite/mentorship-token add-on. Unlock it to access live mentor matching.")
        st.markdown("""**What's included when you activate Mentorship Coach:**
- Curated mentor shortlists sourced from the mentor portal
- Agreement + requirement document workflow
- Session logging with AI-generated feedback
- Growth analytics synced with your resume profile
""")

        st.markdown("#### 🔎 Check Mentor Availability")
        with st.form("mentorship_interest_form", clear_on_submit=True):
            interest_sector = st.selectbox(
                "Target Sector",
                ["Machine Learning", "Data Science", "Engineering Leadership", "Product Management", "Career Transition"],
                index=0
            )
            interest_skill = st.selectbox(
                "Primary Focus Skill",
                options=resume_skills[:10] if resume_skills else ["Leadership", "System Design", "Cloud", "Interview Coaching"],
                index=0
            )
            desired_start = st.date_input("Desired Start Date")
            session_format = st.selectbox("Preferred Format", ["4-session sprint", "8-session transformation", "On-demand office hours"])
            if st.form_submit_button("Submit Availability Request"):
                coaching_state['mentorship_interest_requests'].append({
                    'sector': interest_sector,
                    'skill': interest_skill,
                    'start_date': desired_start.isoformat(),
                    'format': session_format,
                    'submitted_at': datetime.now().isoformat()
                })
                st.success("Request logged. Our concierge team will confirm mentor availability within 1 business day.")

        col1, col2 = st.columns(2)
        with col1:
            if st.button("💳 Purchase Mentorship Tokens", use_container_width=True):
                st.switch_page("pages/05_Payment.py")
        with col2:
            if st.button("🌟 Upgrade to Elite Pro", use_container_width=True):
                st.switch_page("pages/06_Pricing.py")
    else:
        if mentorship_tokens:
            st.success(f"🎟️ {mentorship_tokens} mentorship token(s) available. Each mentor search consumes 1 token.")
        else:
            st.info("Elite/Enterprise tier detected — mentorship searches are included in your plan.")

        subtab1, subtab2, subtab3, subtab4 = st.tabs([
            "💬 Chat with Coach",
            "🔍 Find Mentors",
            "📅 Manage Sessions",
            "📊 Growth Analytics"
        ])

        with subtab1:
            st.subheader("💬 Mentorship Coach Chatbot")
            st.markdown("Get advice on finding mentors, preparing for sessions, and maximizing mentorship value.")

            if 'mentorship' not in st.session_state.coaching_state['chat_history']:
                st.session_state.coaching_state['chat_history']['mentorship'] = [
                    {"role": "assistant", "content": "👋 Hi! I'm your AI Mentorship Coach. What mentorship goal should we tackle today?"}
                ]

            for message in st.session_state.coaching_state['chat_history']['mentorship']:
                with st.chat_message(message["role"]):
                    st.markdown(message["content"])

            if prompt := st.chat_input("Ask about mentor matching, prep, or progress..."):
                st.session_state.coaching_state['chat_history']['mentorship'].append({"role": "user", "content": prompt})
                with st.chat_message("user"):
                    st.markdown(prompt)

                if PORTAL_BRIDGE_AVAILABLE and chat_service:
                    try:
                        context = {
                            "coach_type": "mentorship",
                            "user_tier": user_tier,
                            "resume_data": st.session_state.get('resume_data', {}),
                            "mentorship_goals": st.session_state.get('mentorship_goals', []),
                            "active_mentors": coaching_state.get('mentorship_connections', [])
                        }
                        ai_payload = chat_service.ask(question=prompt, context=context, user_id=user_id)
                        if isinstance(ai_payload, dict):
                            response_text = ai_payload.get('content') or ai_payload.get('answer') or ai_payload.get('message') or "AI coach responded with no content."
                        else:
                            response_text = str(ai_payload)
                        with st.chat_message("assistant"):
                            st.markdown(response_text)
                        st.session_state.coaching_state['chat_history']['mentorship'].append({"role": "assistant", "content": response_text})
                    except Exception as e:
                        st.error(f"⚠️ Mentorship Coach temporarily unavailable: {str(e)}")
                        fallback_response = (
                            "Mentorship insights are paused until the AI bridge returns. Log your next session in Manage Sessions "
                            "so we can sync the notes later."
                        )
                        with st.chat_message("assistant"):
                            st.markdown(fallback_response)
                        st.session_state.coaching_state['chat_history']['mentorship'].append({"role": "assistant", "content": fallback_response})
                else:
                    offline_msg = (
                        "AI mentor matching isn't available offline. Use the Find Mentors tab to search the live directory "
                        "and I'll reference it once the bridge is online."
                    )
                    st.session_state.coaching_state['chat_history']['mentorship'].append({"role": "assistant", "content": offline_msg})
                    with st.chat_message("assistant"):
                        st.markdown(offline_msg)

            st.markdown("---")
            st.markdown("**🚀 Quick Actions**")
            col1, col2, col3 = st.columns(3)
            with col1:
                if st.button("🏪 Mentorship Marketplace", use_container_width=True):
                    st.switch_page("pages/15_Mentorship_Marketplace.py")
            with col2:
                if st.button("📅 Schedule Session", use_container_width=True):
                    if coaching_state['mentorship_connections']:
                        summary = (
                            f"You have {len(coaching_state['mentorship_connections'])} linked mentor(s). "
                            "Open Manage Sessions to confirm the next date."
                        )
                    else:
                        summary = "No mentors linked yet. Add a connection in Manage Sessions before scheduling."
                    st.session_state.coaching_state['chat_history']['mentorship'].append({"role": "assistant", "content": summary})
                    st.rerun()
            with col3:
                if st.button("📊 View My Progress", use_container_width=True):
                    mentorship_sessions = coaching_state.get('mentorship_sessions', [])
                    ratings = [session.get('rating') for session in mentorship_sessions if session.get('rating')]
                    avg_rating = mean(ratings) if ratings else None
                    if avg_rating is not None:
                        progress_summary = (
                            f"Sessions completed: {len(mentorship_sessions)}\n"
                            f"Average rating: {avg_rating:.1f}/5"
                        )
                    elif mentorship_sessions:
                        progress_summary = (
                            f"Sessions completed: {len(mentorship_sessions)}\n"
                            "Add ratings to future logs so I can monitor satisfaction."
                        )
                    else:
                        progress_summary = "No mentorship sessions logged yet. Capture one in Manage Sessions to unlock analytics."
                    st.session_state.coaching_state['chat_history']['mentorship'].append({
                        "role": "assistant",
                        "content": progress_summary
                    })
                    st.rerun()

        with subtab2:
            st.subheader("🔍 Find Mentors & Browse Offers")
            st.info("Search the live mentor directory using your resume and JD signals. No demo data.")

            with st.form("mentor_search_form"):
                sector_options = ["Any", "Machine Learning", "Data Science", "Engineering Leadership", "Product Management", "Career Transition"]
                sector_choice = st.selectbox("Sector", sector_options)
                focus_skill_options = resume_skills if resume_skills else ["Leadership", "Strategy", "Cloud", "AI"]
                focus_skill = st.selectbox("Primary Skill", focus_skill_options)
                session_intent = st.selectbox("Engagement", ["Career Navigation", "Technical Deep Dive", "Interview Coaching"])
                submitted = st.form_submit_button("Search available mentors")

                if submitted:
                    filters = {
                        'sector': None if sector_choice == "Any" else sector_choice,
                        'skill': focus_skill,
                        'intent': session_intent,
                        'searched_at': datetime.now().isoformat()
                    }
                    coaching_state['mentor_search_filters'] = filters
                    with st.spinner("Querying live mentor data..."):
                        search_results = fetch_peer_mentor_suggestions(user_id, filters['skill'], filters['sector'], limit=6)
                    coaching_state['mentor_search_results'] = search_results
                    if search_results:
                        st.success(f"Found {len(search_results)} mentor profile(s) that match your request.")
                    else:
                        st.warning("No mentors matched those filters yet. Try a broader sector or skill.")

            mentor_matches = coaching_state.get('mentor_search_results', [])
            if mentor_matches:
                for match in mentor_matches:
                    title = match.get('role') or "Mentor"
                    with st.expander(f"{match['name']} — {title}"):
                        st.markdown(f"**Company**: {match.get('company', '—')}")
                        st.markdown(f"**Experience**: {match.get('experience_years', '—')} years")
                        if match.get('industry'):
                            st.markdown(f"**Industry**: {match['industry']}")
                        if match.get('skills'):
                            st.markdown("**Skills**: " + ", ".join(match['skills'][:8]))
                        if st.button(f"Request intro to {match['name']}", key=f"intro_{match['name']}"):
                            coaching_state['mentorship_connections'].append({
                                'mentor_name': match['name'],
                                'focus': focus_skill,
                                'status': 'requested',
                                'requested_at': datetime.now().isoformat()
                            })
                            st.success("Intro request saved. Check Manage Sessions for updates.")
                            st.rerun()
            else:
                st.info("Run a search above to surface mentor candidates from the live dataset.")

            if st.button("🏪 Open Mentorship Marketplace", use_container_width=True):
                st.switch_page("pages/15_Mentorship_Marketplace.py")

        with subtab3:
            st.subheader("📅 Mentorship Sessions Management")
            st.markdown("#### 🤝 Active Mentorship Connections")

            with st.expander("➕ Link Mentorship Connection"):
                with st.form("add_mentorship_connection"):
                    default_focus = coaching_state.get('mentor_search_filters', {}).get('skill') or (resume_skills[0] if resume_skills else "")
                    mentor_name = st.text_input("Mentor Name")
                    mentor_focus = st.text_input("Focus Area", value=default_focus)
                    next_session = st.date_input("Next Session Date")
                    status = st.selectbox("Status", ["🟢 Active", "🟡 Pending", "⚪️ Requested"])
                    if st.form_submit_button("Save Connection"):
                        if mentor_name.strip():
                            coaching_state['mentorship_connections'].append({
                                'mentor_name': mentor_name.strip(),
                                'focus': mentor_focus.strip(),
                                'next_session': next_session.isoformat(),
                                'status': status
                            })
                            st.success("Mentorship connection saved.")
                            st.rerun()
                        else:
                            st.error("Mentor name is required.")

            if coaching_state['mentorship_connections']:
                connection_rows = []
                for conn in coaching_state['mentorship_connections']:
                    connection_rows.append({
                        'Mentor': conn.get('mentor_name'),
                        'Focus': conn.get('focus', '—'),
                        'Next Session': conn.get('next_session', '—'),
                        'Status': conn.get('status', '—')
                    })
                st.dataframe(pd.DataFrame(connection_rows), use_container_width=True, hide_index=True)
            else:
                st.info("No mentorship connections recorded yet.")

            st.markdown("---")
            st.markdown("#### 📚 Session History")

            mentorship_sessions = coaching_state.get('mentorship_sessions', [])
            with st.expander("📝 Log Mentorship Session"):
                with st.form("log_mentorship_session"):
                    mentor_options = [conn.get('mentor_name') for conn in coaching_state['mentorship_connections'] if conn.get('mentor_name')]
                    mentor_choice = st.selectbox("Mentor", mentor_options or ["Add a mentor above first"], disabled=not mentor_options)
                    session_date = st.date_input("Session Date")
                    duration_hours = st.number_input("Duration (hours)", min_value=0.5, max_value=8.0, value=1.0, step=0.5)
                    session_rating = st.slider("Session Rating", 1, 5, 4)
                    skills_focus = st.multiselect("Skills Focused On", options=resume_skills)
                    goal_status = st.selectbox("Goal Status", ["in-progress", "achieved", "blocked"])
                    session_notes = st.text_area("Key Outcomes")

                    if st.form_submit_button("Log Session", disabled=not mentor_options):
                        session_record = {
                            'mentor_name': mentor_choice,
                            'date': session_date.isoformat(),
                            'duration_hours': duration_hours,
                            'rating': session_rating,
                            'skills_focus': skills_focus,
                            'goal_status': goal_status,
                            'notes': session_notes
                        }
                        coaching_state['mentorship_sessions'].append(session_record)
                        st.success("Session logged successfully.")
                        st.rerun()

            if mentorship_sessions:
                session_rows = []
                for entry in reversed(mentorship_sessions[-20:]):
                    session_rows.append({
                        'Date': entry.get('date', '')[:10],
                        'Mentor': entry.get('mentor_name', '—'),
                        'Duration (h)': entry.get('duration_hours', 0),
                        'Rating': entry.get('rating', '—'),
                        'Skills': ", ".join(entry.get('skills_focus', [])),
                        'Notes': entry.get('notes', '')
                    })
                st.dataframe(pd.DataFrame(session_rows), use_container_width=True, hide_index=True)
            else:
                st.info("Log your first mentorship session to build a history.")

        with subtab4:
            st.subheader("📊 Mentorship Growth Analytics")
            mentorship_sessions = coaching_state.get('mentorship_sessions', [])
            mentorship_connections = coaching_state.get('mentorship_connections', [])

            col1, col2 = st.columns(2)

            with col1:
                st.markdown("#### 📈 Mentorship Impact")
                impact_cols = st.columns(2)
                total_sessions = len(mentorship_sessions)
                goals_achieved = sum(1 for session in mentorship_sessions if session.get('goal_status') == 'achieved')
                unique_mentors = len({conn.get('mentor_name') for conn in mentorship_connections if conn.get('mentor_name')})
                ratings = [session.get('rating') for session in mentorship_sessions if session.get('rating')]
                avg_rating = mean(ratings) if ratings else None

                with impact_cols[0]:
                    st.metric("Total Sessions", total_sessions)
                    st.metric("Goals Achieved", goals_achieved)
                with impact_cols[1]:
                    st.metric("Active Mentors", unique_mentors)
                    st.metric("Avg Session Rating", f"{avg_rating:.1f}/5" if avg_rating else "—")

                if mentorship_sessions:
                    timeline_df = pd.DataFrame(mentorship_sessions)
                    timeline_df['date'] = pd.to_datetime(timeline_df['date'])
                    timeline_df['Month'] = timeline_df['date'].dt.strftime('%Y-%m')
                    timeline_df['Sessions'] = 1
                else:
                    timeline_df = pd.DataFrame()

                if not timeline_df.empty:
                    monthly = timeline_df.groupby('Month').agg({'Sessions': 'sum', 'duration_hours': 'sum'}).reset_index()
                    fig = go.Figure()
                    fig.add_trace(go.Bar(name='Sessions', x=monthly['Month'], y=monthly['Sessions']))
                    fig.add_trace(go.Bar(name='Hours', x=monthly['Month'], y=monthly['duration_hours']))
                    fig.update_layout(title='Mentorship Activity', barmode='group', height=300)
                    st.plotly_chart(fig, use_container_width=True)
                else:
                    st.info("Log mentorship sessions to unlock the activity chart.")

            with col2:
                st.markdown("#### 🎯 Skills Developed")
                focus_counter = Counter()
                for session in mentorship_sessions:
                    for skill in session.get('skills_focus', []):
                        focus_counter[skill] += 1

                if focus_counter:
                    skill_df = pd.DataFrame({
                        'Skill': list(focus_counter.keys()),
                        'Sessions': list(focus_counter.values())
                    }).sort_values('Sessions', ascending=False)
                    fig = px.bar(skill_df, x='Skill', y='Sessions', title='Sessions per Skill', color='Sessions')
                    fig.update_layout(height=300, showlegend=False)
                    st.plotly_chart(fig, use_container_width=True)
                else:
                    st.info("Assign skill focus tags to mentorship sessions to monitor progress.")

                st.markdown("#### 💡 Key Achievements")
                achievements: List[str] = []
                if goals_achieved:
                    achievements.append(f"✅ {goals_achieved} goal(s) completed through mentorship support")
                if unique_mentors:
                    achievements.append(f"✅ Built a network of {unique_mentors} active mentor(s)")
                if avg_rating:
                    achievements.append(f"✅ Maintained an average satisfaction score of {avg_rating:.1f}/5")
                if not achievements:
                    st.info("Once you log sessions, key wins will appear here automatically.")
                else:
                    for item in achievements:
                        st.markdown(item)

# Footer
st.markdown("---")
st.markdown("### 🎓 Continue Your Journey")

footer_col1, footer_col2, footer_col3 = st.columns(3)

with footer_col1:
    st.markdown("**📚 More Coaching Resources**")
    if st.button("📖 Coaching Library", use_container_width=True):
        st.info("Access to coaching articles, videos, and resources")

with footer_col2:
    st.markdown("**🌟 Premium Features**")
    if st.button("🏪 Mentorship Marketplace", use_container_width=True):
        st.switch_page("pages/15_Mentorship_Marketplace.py")

with footer_col3:
    st.markdown("**⚙️ Settings**")
    if st.button("🔧 Coaching Preferences", use_container_width=True):
        st.info("Customize your coaching experience")

# Debug mode
if st.checkbox("🔧 Debug: Show Coaching State", value=False):
    st.json(st.session_state.coaching_state)

